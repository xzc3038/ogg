module.exports = {
    name: "抽奖",
    uniacid: "2",
    acid: "2",
    multiid: "0",
    version: "5.2.5",
    siteroot: "https://www.xiazhicai.top/app/index.php",
    design_method: "3"
};
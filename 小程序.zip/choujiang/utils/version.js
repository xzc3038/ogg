module.exports = {
    version: "debug"
};
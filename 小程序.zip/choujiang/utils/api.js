var t = require("md5.js"), e = "https://api.cj.9w9.com", n = function () {
  var t = new Date().getTime() / 1e3;
  return parseInt(t);
}, r = function (e) {
  
}, o = function (t, e) {
  1 == t.num && wx.showToast({
    title: "正在加载中",
    icon: "loading",
    duration: 5e3
  }), 5 == t.num && wx.showLoading({
    title: "正在加载中"
  });
  var n = t.data || [];
  n.token = wx.getStorageSync("token"), n.openid = wx.getStorageSync("openid"), n.uid = wx.getStorageSync("uid"),
    wx.request({
      url: e,
      method: t.method || "POST",
      data: n,
      header: {
        "Cotent-Type": "application/json",
        "api-token": r(wx.getStorageSync("timeDiff"))
      },
      success: function (e) {
        e.data.token && wx.setStorageSync("token", e.data.token), wx.setStorageSync("msgCount", e.data.msg_count),
          50003 != e.data.code && 50004 != e.data.code && 1e4 != e.data.code || t.success && t.success(e),
          50002 == e.data.code && t.success && t.success(e), 7e4 != e.data.code ? 0 == e.data.code ? (e.data.msg_count,
            t.success && t.success(e), 1 == t.num && wx.hideToast(), 5 == t.num && wx.hideLoading()) : wx.showToast({
              title: e.data.error,
              icon: "none",
              duration: 2e3,
              success: function (t) { }
            }) : t.success && t.success(e);
      },
      fail: function (e) {
        console.log(e), 5 == t.num && wx.hideLoading(), t.fail && t.fail(e);
      },
      complete: function (e) {
        t.complete && t.complete(e);
      }
    });
};

module.exports = {
  host: e,
  GetLength: function (t) {
    for (var e = 0, n = t.length, r = -1, o = 0; o < n; o++) e += (r = t.charCodeAt(o)) >= 0 && r <= 128 ? 1 : 2;
    return e;
  },
  timeTransform: function (t) {
    var e = new Date(1e3 * t), n = e.getFullYear(), r = e.getMonth() + 1, o = e.getDate(), i = e.getHours(), s = e.getMinutes();
    e.getSeconds();
    i < 10 && (i = "0" + i), s < 10 && (s = "0" + s);
    var u = new Date(), c = u.getTime() - 1e3 * t;
    return c <= 6e4 ? "1分钟前" : 6e4 < c && c <= 36e5 ? Math.round(c / 6e4) + "分钟前" : 36e5 < c && c <= 864e5 ? Math.round(c / 36e5) + "小时前" : 864e5 < c && c <= 1728e5 ? "昨天" : 1728e5 < c && c <= 2592e5 ? "前天" : (c > 2592e5 && u.getFullYear(),
      n + "-" + r + "-" + o + " " + i + ":" + s);
  },
  saveUserInfo: function (t) {
    return o(t, e + "/user/save_userinfo");
  },
  sendFormid: function (t) {
    return o(t, e + "/formid/add_formid");
  },
  getIndexPageList: function (t) {
    return o(t, e + "/lottery/index_list");
  },
  getAcDetail: function (t) {
    return o(t, e + "/lottery/detail");
  },
  partLottery: function (t) {
    return o(t, e + "/lottery/join");
  },
  report: function (t) {
    return o(t, e + "/report/create");
  },
  awardList: function (t) {
    return o(t, e + "/lottery/award_list");
  },
  luckDraw: function (t) {
    return o(t, e + "/lottery/create");
  },
  getUserInfo: function (t) {
    return o(t, e + "/user/get_userinfo/");
  },
  savePhone: function (t) {
    return o(t, e + "/user/save_phone");
  },
  getCashflow: function (t) {
    return o(t, e + "/cashflow/list");
  },
  modifyUserSeting: function (t) {
    return o(t, e + "/user/set_u_setting");
  },
  commonProblem: function (t) {
    return o(t, e + "/article/list");
  },
  myReleaseList: function (t) {
    return o(t, e + "/writings/my_list");
  },
  myReplyList: function (t) {
    return o(t, e + "/writings/my_comment_list");
  },
  modifyMsgStatus: function (t) {
    return o(t, e + "/msg/set_read");
  },
  getQnyToken: function (t) {
    return o(t, e + "/qny/qny_token");
  },
  getLottery: function (t) {
    return o(t, e + "/writings/confirm_lottery");
  },
  getBarrageList: function (t) {
    return o(t, e + "/writings/barrage");
  },
  modityUserInfo: function (t) {
    return o(t, e + "/user/change_userinfo");
  },
  reportLine: function (t) {
    return t.split("&hc").join("\n");
  },
  apiToken: r,
  get_time: n,
  getLotteryCode: function (t) {
    return o(t, e + "/lottery/get_qrcode");
  },
  getAllPartName: function (t) {
    return o(t, e + "/lottery/join_list");
  },
  getMyLottery: function (t) {
    return o(t, e + "/lottery/my_lottery");
  },
  editAddress: function (t) {
    return o(t, e + "/lottery/address_edit");
  },
  getAddress: function (t) {
    return o(t, e + "/lottery/address_list");
  },
  getSelfAddress: function (t) {
    return o(t, e + "/lottery/my_award_address");
  },
  eidtLottery: function (t) {
    return o(t, e + "/lottery/edit_info");
  },
  autoLottery: function (t) {
    return o(t, e + "/lottery/open_award");
  },
  checkPassword: function (t) {
    return o(t, e + "/lottery/check_password");
  },
  codeOrder: function (t) {
    return o(t, e + "/lottery/code_order");
  },
  mineCode: function (t) {
    return o(t, e + "/lottery/my_code");
  },
  getSign: function (t) {
    return o(t, e + "/sign/sign");
  },
  getSignInfo: function (t) {
    return o(t, e + "/sign/sign_data");
  },
  luckyGet: function (t) {
    return o(t, e + "/lucky/lucky_get");
  },
  friendShare: function (t) {
    return o(t, e + "/share/share_friend");
  },
  shareList: function (t) {
    return o(t, e + "/share/share_list");
  },
  setNotice: function (t) {
    return o(t, e + "/sign/set_sign_notice");
  },
  getTask: function (t) {
    return o(t, e + "/lucky/get_task_new");
  },
  getTaskList: function (t) {
    return o(t, e + "/task/task_list");
  },
  getTaskCoin: function (t) {
    return o(t, e + "/task/task_get");
  },
  luckRecord: function (t) {
    return o(t, e + "/lucky/detail_list");
  },
  getGoodsList: function (t) {
    return o(t, e + "/goods/goods_list");
  },
  getShopDetail: function (t) {
    return o(t, e + "/goods/goods_detail");
  },
  exchangeGoods: function (t) {
    return o(t, e + "/goods/exchange_goods");
  },
  wallet: function (t) {
    return o(t, e + "/cashflow/wallet");
  },
  complain: function (t) {
    return o(t, e + "/lottery/complain");
  }
};
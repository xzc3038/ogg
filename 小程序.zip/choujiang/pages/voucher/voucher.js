function _defineProperty(t, e, a) {
    return e in t ? Object.defineProperty(t, e, {
        value: a,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : t[e] = a, t;
}

var tools = require("../../utils/tools.js");

function myLaunch(a) {
    var t = {
        trd_session: wx.getStorageSync("trd_session")
    };
    t.p = a.data.p1;
    var e = getApp();
    tools.requset("?i=" + e.siteInfo.uniacid + "&c=entry&op=receive_card&do=voucherList&m=" + e.modules_name + "&a=wxapp", t, function(t) {
        t = t.info;
        console.log(t);
        for (var e = 0; e < t.length; e++) t[e].addtime = timestampToTime(t[e].created);
        a.setData({
            lucklist: t,
            noData: !1
        });
    });
}

function myPart(a) {
    var t = wx.getStorageSync("trd_session"), e = _defineProperty({
        trd_session: t
    }, "trd_session", t);
    e.p = a.data.p2;
    var n = getApp();
    tools.requset("?i=" + n.siteInfo.uniacid + "&c=entry&op=receive_card&do=voucherList&m=" + n.modules_name + "&a=wxapp", e, function(t) {
        t = t.info;
        console.log(t);
        for (var e = 0; e < t.length; e++) t[e].addtime = timestampToTime(t[e].created);
        a.setData({
            lucklist: t,
            noData: !1
        });
    });
}

function timestampToTime(t) {
    var e = new Date(1e3 * t);
    return e.getFullYear() + "-" + ((e.getMonth() + 1 < 10 ? "0" + (e.getMonth() + 1) : e.getMonth() + 1) + "-") + (e.getDate() + " ") + (e.getHours() + ":") + (e.getMinutes() + ":") + (e.getSeconds() < 10 ? "0" + e.getSeconds() : e.getSeconds());
}

Page({
    data: {
        unitid: tools.unitid,
        headtxt: "卡券",
        navOn: 1,
        p1: 1,
        p2: 1,
        show_adv: 2,
        adv: [],
        currTabFlagVal: 0
    },
    onLoad: function(t) {
        var e = this;
        getApp().tabhead(e), myPart(e), e.setData({
            currTabFlagVal: getApp().globalData.currTabFlag
        });
    },
    pagegoback: function() {
        wx.navigateBack({
            delta: 1
        });
    },
    advjump: function(t) {
        var e = this;
        wx.navigateToMiniProgram({
            appId: e.data.adv.appId,
            path: e.data.adv.xcx_path,
            extraData: e.data.adv.extradata,
            success: function(t) {
                console.log("success");
            },
            fail: function(t) {
                wx.showModal({
                    title: "",
                    content: t.errMsg,
                    showCancel: !1
                });
            }
        });
    },
    onReady: function() {
        var e = this, t = getApp(), a = {
            trd_session: wx.getStorageSync("trd_session"),
            get_type: "voucher_a"
        };
        tools.requset("?i=" + t.siteInfo.uniacid + "&c=entry&op=receive_card&do=advertisement&m=" + t.modules_name + "&a=wxapp", a, function(t) {
            e.setData({
                show_adv: t.status
            }), console.log(t.info.advertisement), 1 == t.status && (e.setData({
                adv_type: t.info.type,
                advertisement: t.info.advertisement
            }), e.data.adv = t.info.advertisement);
        });
    },
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {},
    navSwitch: function(t) {
        var e = this, a = t.currentTarget.dataset.id;
        e.data.navOn != a && (e.setData({
            lucklist: [],
            noData: !0
        }), e.setData({
            navOn: a
        }), 1 == a ? myPart(e) : myLaunch(e));
    },
    detail: function(t) {
        var e = t.currentTarget.dataset.id;
        if (1 == t.currentTarget.dataset.status) return !0;
        wx.navigateTo({
            url: "../qrvoucher/qrvoucher?id=" + e
        });
    }
});
var tools = require("../../utils/tools.js");

function balance(a) {
    var t = wx.getStorageSync("trd_session"), e = getApp();
    tools.requset("?i=" + e.siteInfo.uniacid + "&c=entry&op=receive_card&do=my&m=" + e.modules_name + "&a=wxapp", {
        trd_session: t
    }, function(t) {
        console.log(t.info.money), a.setData({
            info: t.info.money
        });
    });
}

Page({
    data: {
        unitid: tools.unitid,
        headtxt: "提现",
        money: "",
        sub: 1,
        show_adv: 2,
        adv: []
    },
    onLoad: function(t) {
        var a = this;
        getApp().tabhead(a), balance(a);
        var e = getApp(), o = {
            trd_session: wx.getStorageSync("trd_session"),
            get_type: "withdrawals_a"
        };
        tools.requset("?i=" + e.siteInfo.uniacid + "&c=entry&op=receive_card&do=advertisement&m=" + e.modules_name + "&a=wxapp", o, function(t) {
            a.setData({
                show_adv: t.status
            }), console.log(t.info.advertisement), 1 == t.status && (a.setData({
                adv_type: t.info.type,
                advertisement: t.info.advertisement
            }), a.data.adv = t.info.advertisement);
        }), a.setData({
            currTabFlagVal: getApp().globalData.currTabFlag
        });
    },
    pagegoback: function() {
        wx.navigateBack({
            delta: 1
        });
    },
    onReady: function() {
        getApp();
    },
    onShow: function() {},
    advjump: function(t) {
        var a = this;
        wx.navigateToMiniProgram({
            appId: a.data.adv.appId,
            path: a.data.adv.xcx_path,
            extraData: a.data.adv.extradata,
            success: function(t) {
                console.log("success");
            },
            fail: function(t) {
                wx.showModal({
                    title: "",
                    content: t.errMsg,
                    showCancel: !1
                });
            }
        });
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {},
    allout: function(t) {
        var a = this.data.info;
        this.setData({
            money: a
        });
    },
    moneyInput: function(t) {
        var a = "";
        a = parseFloat(t.detail.value) > this.data.info ? this.data.info : t.detail.value, 
        this.setData({
            money: a
        });
    },
    submit: function(t) {
        var a = this;
        if ("" != a.data.money) {
            if (2 == this.data.sub) return !1;
            this.data.sub = 2;
            var e = getApp(), o = {};
            o.money = a.data.money, o.formid = t.detail.formId, o.trd_session = wx.getStorageSync("trd_session"), 
            tools.requset("?i=" + e.siteInfo.uniacid + "&c=entry&op=receive_card&do=withdrawals&m=" + e.modules_name + "&a=wxapp", o, function(t) {
                (a.data.sub = 1) == t.status && wx.showModal({
                    title: "提示",
                    mask: !0,
                    content: "提现成功",
                    showCancel: !1,
                    success: function(t) {
                        t.confirm;
                    }
                }), balance(a);
            });
        } else tools.showNotice("请输入提现金额");
    }
});
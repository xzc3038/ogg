var tools = require("../../utils/tools.js"), QR = require("../../utils/qrcode.js"), WxParse = require("../../wxParse/wxParse.js"), touchDot = 0, touchend = 0;

Page({
  data: {
      good:[],
      notEnough:!1,
      cha:0,
      exchange:!1,
      account: '',
      password: '',
      atype: !0
  },
  onLoad: function (e) {
    var t = this, a = getApp(), s = {
      trd_session: wx.getStorageSync("trd_session"),
      gid:e.gid
    };
    tools.requset("?i=" + a.siteInfo.uniacid + "&c=entry&op=receive_card&do=good&m=" + a.modules_name + "&a=wxapp", s, function (e) {
    
      t.setData({
        good: e.info
      });
    }), getApp().tabhead(t);
  },
  popClose: function (t) {
    this.setData({
      notEnough: !1,
      exchange: !1,
      phoneNumber: !1,
      exchangeSuccess: !1,
      isTip: !1
    });
  },
  changeNow: function(e){
    var t = this, a = getApp(), s = {
      trd_session: wx.getStorageSync("trd_session"),
      gid: e.detail.value.gid
    };
    tools.requset("?i=" + a.siteInfo.uniacid + "&c=entry&op=receive_card&do=change&m=" + a.modules_name + "&a=wxapp", s, function (e) {
      console.log(e.info);
      if (e.info.status==0){
        t.setData({
          notEnough: !0,
          cha: e.info.cha
        });
      } else if (e.info.status == 1){
        wx.showToast({
          title: '库存不足~',
          icon: 'none'
        });
      } else if (e.info.status == 2){
        wx.showToast({
          title: '积分更新错误~',
          icon: 'none'
        });
      } else if (e.info.status == 3){
        wx.showToast({
          title: '库存更新错误~',
          icon: 'none'
        });
      } else if (e.info.status == 4) {
        wx.showToast({
          title: '历史更新错误~',
          icon: 'none'
        });
      } else if (e.info.status == 6) {
        wx.showToast({
          title: '奖品获取失败~',
          icon: 'none'
        });
      } else if (e.info.status == 7) {
        wx.showToast({
          title: '更新奖品获取~',
          icon: 'none'
        });
      } else if (e.info.status == 5) {
        if (e.info.gtype == "1"){
          if (e.info.atype == 1) {
            t.setData({
              exchange: !0,
              account: e.info.account,
              password: e.info.password
            });
          } else if (e.info.atype == 0) {
            var up = "good.nstock";
            t.setData({
              exchange: !0,
              atype: !1,
              account: e.info.account,
              password: '无',
              [up]: e.info.stock
            });
          }
        }else{
        
        }
        
      }
    });
  },
  yes:function(){
    this.setData({
      exchange: !1
    });  
  }
});
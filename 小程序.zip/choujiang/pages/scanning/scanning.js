function _defineProperty(e, t, o) {
    return t in e ? Object.defineProperty(e, t, {
        value: o,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[t] = o, e;
}

var tools = require("../../utils/tools.js");

function actDetail(e) {
    var t = wx.getStorageSync("trd_session");
    _defineProperty({
        trd_session: t
    }, "trd_session", t).id = e.data.id;
    getApp();
}

Page({
    data: {
        maskHidden: !0,
        imagePath: "",
        voucher: ""
    },
    canvasId: "qrcCanvas",
    onLoad: function(e) {
        var t = this;
        getApp().tabhead(t), e.id && (t.data.id = e.id), t.setData({
            currTabFlagVal: getApp().globalData.currTabFlag
        });
    },
    pagegoback: function() {
        wx.navigateBack({
            delta: 1
        });
    },
    onReady: function() {
        this.setData({
            scan: 0
        });
    },
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onGenQrc: function() {
        var s = this;
        wx.scanCode({
            success: function(e) {
                var t;
                console.log(e);
                var o = wx.getStorageSync("trd_session"), n = (_defineProperty(t = {
                    trd_session: o
                }, "trd_session", o), _defineProperty(t, "voucher", e.result), t);
                s.data.voucher = e.result;
                var a = getApp();
                tools.requset("?i=" + a.siteInfo.uniacid + "&c=entry&op=receive_card&do=writeoff&m=" + a.modules_name + "&a=wxapp", n, function(e) {
                    1 == e.status && (wx.showModal({
                        title: "提示",
                        mask: !0,
                        content: "核销成功",
                        showCancel: !1,
                        success: function(e) {
                            e.confirm;
                        },
                        fail: function(e) {
                            console.log(e);
                        }
                    }), s.setData({
                        scan: e.info.scan
                    }));
                });
            }
        });
    },
    writeOrder: function(e) {
        var t = this, o = {
            trd_session: wx.getStorageSync("trd_session"),
            order_id: this.data.order_id,
            voucher: t.data.voucher
        }, n = getApp();
        tools.requset("?i=" + n.siteInfo.uniacid + "&c=entry&op=receive_card&do=writeOrder&m=" + n.modules_name + "&a=wxapp", o, function(e) {
            1 == e.status && t.setData({
                scan: 0
            });
        });
    },
    orderInput: function(e) {
        this.data.order_id = e.detail.value, console.log(e), console.log(this.data.order_id);
    },
    onShareAppMessage: function() {},
    prese: function(e) {
        wx.showLoading({
            title: "保存中",
            mask: !0
        }), wx.downloadFile({
            url: this.data.url,
            success: function(e) {
                200 === e.statusCode && (wx.hideLoading(), wx.saveImageToPhotosAlbum({
                    filePath: e.tempFilePath,
                    success: function(e) {
                        wx.showToast({
                            title: "保存成功"
                        });
                    },
                    fail: function(e) {
                        tools.showNotice("保存失败");
                    }
                }));
            },
            fail: function(e) {
                wx.hideLoading(), tools.showNotice("保存失败");
            }
        });
    }
});
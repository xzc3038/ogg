var tools = require("../../utils/tools.js"), app = getApp();

function getPrize(a) {
    var t = wx.getStorageSync("trd_session"), e = getApp();
    tools.requset("?i=" + e.siteInfo.uniacid + "&c=entry&op=receive_card&do=index&m=" + e.modules_name + "&a=wxapp", {
        trd_session: t
    }, function(t) {
      for (var e in console.log(t), t.info.prize) t.info.prize[e].typevalue = 1 == t.info.prize[e].type ? timestampToTime(t.info.prize[e].typevalue) : t.info.prize[e].typevalue, 
        t.info.prize[e].addtime = timestampToTime(t.info.prize[e].created);
        console.log(t.info);
        a.setData({
          info: t.info.prize,
          codeList: t.info.codeList,
          version2List: t.info.version2List,
          wrapHidden: !1
        });
    });
}

function total(e) {
    var t = getApp(), a = wx.getStorageSync("trd_session");
    tools.requset("?i=" + t.siteInfo.uniacid + "&c=entry&op=receive_card&do=total&m=" + t.modules_name + "&a=wxapp", {
        trd_session: a
    }, function(t) {
        e.setData({
            total: t.info
        });
    });
}

function timestampToTime(t) {
    var e = new Date(1e3 * t);
    return e.getFullYear() + "-" + ((e.getMonth() + 1 < 10 ? "0" + (e.getMonth() + 1) : e.getMonth() + 1) + "-") + (e.getDate() + " ") + (e.getHours() + ":") + (e.getMinutes() + ":") + (e.getSeconds() < 10 ? "0" + e.getSeconds() : e.getSeconds());
}

Page({
    data: {
        wrapHidden: !0,
        tabhead: "首页",
        unitid: tools.unitid,
        show_adv: 2,
        adv: []
    },
    onLoad: function(t) {
        var e = this, a = getApp(), o = {
            trd_session: wx.getStorageSync("trd_session"),
            key: "title,alipay_pwd"
        };
        getApp().globalData.currTabFlag = "news", tools.requset("?i=" + a.siteInfo.uniacid + "&c=entry&op=receive_card&do=configarr&m=" + a.modules_name + "&a=wxapp", o, function(t) {
            e.setData({
                headtxt: t.info.title ? t.info.title : "抽奖小助手",
                alipay_pwd: t.info.alipay_pwd
            });
        });
        o = {
            trd_session: wx.getStorageSync("trd_session"),
            get_type: "news_a"
        };
        tools.requset("?i=" + a.siteInfo.uniacid + "&c=entry&op=receive_card&do=advertisement&m=" + a.modules_name + "&a=wxapp", o, function(t) {
            e.setData({
                show_adv: t.status
            }), 1 == t.status && (e.setData({
                adv_type: t.info.type,
                advertisement: t.info.advertisement
            }), e.data.adv = t.info.advertisement);
        }), a.editTabBar(), a.tabhead(e), getPrize(e), total(e);
    },
    onReady: function() {},
    onShow: function() {
        0;
    },
    waitandjump: function(t) {
        wx.showToast({
            title: "拼命加载中",
            icon: "loading",
            duration: 500
        }), setTimeout(function() {
            wx.reLaunch({
                url: t
            });
        }, 500);
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {
      getPrize(this), total(this);
      wx.stopPullDownRefresh();
    },
    onReachBottom: function() {},
    onShareAppMessage: function() {},
    getUserInfo: function(t) {
        tools.userInfo(this, t);
    },
    todayPrize: function(t) {
        var e = t.currentTarget.dataset.id;
        wx.redirectTo({
            url: "../partake/partake?id=" + e
        });
    },
    soonDetail: function(t) {
        var e = t.currentTarget.dataset.id;
        wx.navigateTo({
            url: "../partake/partake?id=" + e
        });
    },
    advjump: function(t) {
        var e = this;
        wx.navigateToMiniProgram({
            appId: e.data.adv.appId,
            path: e.data.adv.xcx_path,
            extraData: e.data.adv.extradata,
            success: function(t) {
                console.log("success");
            },
            fail: function(t) {
                wx.showModal({
                    title: "",
                    content: t.errMsg,
                    showCancel: !1
                });
            }
        });
    },
  help: function (t) {
    wx.redirectTo({
      url: "../help/help"
    });
  }
});
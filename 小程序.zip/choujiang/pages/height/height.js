var tools = require("../../utils/tools.js"), app = getApp();
Page({
  data:{
    item:''
  },
  onLoad: function(){
    var t = this, a = getApp();
    t.setData({
      headtxt: "自助福利"
    });
    var o = {
      trd_session: wx.getStorageSync("trd_session")
    };
    tools.requset("?i=" + a.siteInfo.uniacid + "&c=entry&op=receive_card&do=height&m=" + a.modules_name + "&a=wxapp", o, function (e) {
      t.setData({
          item: e.info
      })
    }), getApp().tabhead(t);
  },
  todayPrize: function (t) {
    var e = t.currentTarget.dataset.id;
    wx.redirectTo({
      url: "../partake/partake?id=" + e
    });
  },
})

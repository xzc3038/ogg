function _defineProperty(e, o, t) {
    return o in e ? Object.defineProperty(e, o, {
        value: t,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[o] = t, e;
}

var tools = require("../../utils/tools.js"), QR = require("../../utils/qrcode.js");

function actDetail(o) {
    var e = wx.getStorageSync("trd_session"), t = _defineProperty({
        trd_session: e
    }, "trd_session", e);
    t.id = o.data.id;
    var n = getApp();
    tools.requset("?i=" + n.siteInfo.uniacid + "&c=entry&op=receive_card&do=voucherDetails&m=" + n.modules_name + "&a=wxapp", t, function(e) {
        o.setData({
            info: e.info
        }), o.size = o.setCanvasSize(), console.log(o.size), o.createQrCode(e.info.voucher, o.canvasId, o.size.w, o.size.h);
    });
}

Page({
    data: {
        headtxt: "卡券二维码",
        qrcStr: "",
        qrcPhld: "维康云u=1001",
        maskHidden: !0,
        imagePath: ""
    },
    canvasId: "qrcCanvas",
    onLoad: function(e) {
        var o = this;
        getApp().tabhead(o), e.id && (o.data.id = e.id), actDetail(o);
    },
    onReady: function() {},
    setCanvasSize: function() {
        var e = {};
        try {
            var o = wx.getSystemInfoSync(), t = o.windowWidth / (750 / 686), n = t;
            e.w = t, e.h = n;
        } catch (e) {
            console.log("获取设备信息失败" + e);
        }
        return e;
    },
    createQrCode: function(e, o, t, n) {
        QR.api.draw(e, o, t, n);
    },
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {},
    prese: function(e) {
        wx.showLoading({
            title: "保存中",
            mask: !0
        }), wx.downloadFile({
            url: this.data.url,
            success: function(e) {
                200 === e.statusCode && (wx.hideLoading(), wx.saveImageToPhotosAlbum({
                    filePath: e.tempFilePath,
                    success: function(e) {
                        wx.showToast({
                            title: "保存成功"
                        });
                    },
                    fail: function(e) {
                        tools.showNotice("保存失败");
                    }
                }));
            },
            fail: function(e) {
                wx.hideLoading(), tools.showNotice("保存失败");
            }
        });
    }
});
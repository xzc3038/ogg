function _defineProperty(t, a, e) {
    return a in t ? Object.defineProperty(t, a, {
        value: e,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : t[a] = e, t;
}

var that, tools = require("../../utils/tools.js");

function imlist(a) {
    var t = {}, e = wx.getStorageSync("trd_session");
    t.trd_session = e, t.id = a.data.id, t.p = a.data.p, t.type = a.data.type, tools.requset("/Prize/userlist", t, function(t) {
        console.log(t);
        t = t.info;
        1 < a.data.p && (t = a.data.info.concat(t)), a.setData({
            info: t
        });
    });
}

Page({
    data: {
        layer: !0,
        p: 1,
        p2: 1
    },
    onLoad: function(t) {
        that = this, t.id && (that.data.id = t.id), imlist(that);
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {
        that.data.p += 1, imlist(that);
    },
    onShareAppMessage: function() {},
    detail: function(t) {
        that.data.p2 = 1;
        var a = t.currentTarget.dataset.id, e = {}, o = wx.getStorageSync("trd_session");
        (e = _defineProperty({
            trd_session: o
        }, "trd_session", o)).member_id = a, e.id = that.data.id, e.p = that.data.p2, tools.requset("/Prize/usercodelist", e, function(t) {
            console.log(t);
            t = t.info;
            1 < that.data.p2 && (t = that.data.usercodelist.concat(t)), that.setData({
                usercodelist: t,
                layer: !1,
                member_id: a
            });
        });
    },
    colose: function(t) {
        that.setData({
            layer: !0
        });
    },
    more: function(t) {
        that.data.p2 += 1;
        var a = that.data.member_id, e = {}, o = wx.getStorageSync("trd_session");
        (e = _defineProperty({
            trd_session: o
        }, "trd_session", o)).member_id = a, e.id = that.data.id, e.p = that.data.p2, tools.requset("/Prize/usercodelist", e, function(t) {
            console.log(t);
            t = t.info;
            1 < that.data.p2 && (t = that.data.usercodelist.concat(t)), that.setData({
                usercodelist: t
            });
        });
    }
});
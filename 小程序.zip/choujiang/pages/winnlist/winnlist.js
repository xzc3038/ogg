var that, tools = require("../../utils/tools.js");

function winnlist(i) {
    var t = wx.getStorageSync("trd_session"), a = {};
    a.trd_session = t, a.id = i.data.id;
    var n = getApp();
    tools.requset("?i=" + n.siteInfo.uniacid + "&c=entry&op=receive_card&do=prizeWins&m=" + n.modules_name + "&a=wxapp", a, function(t) {
        console.log(t), i.setData({
            list: t.info
        });
    });
}

Page({
    data: {},
    onLoad: function(t) {
        that = this, t.id && (that.data.id = t.id), that.setData({
            headtxt: "中奖人信息"
        }), getApp().tabhead(that), winnlist(that);
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {},
    companyInput: function(t) {
        var i = that.data.list;
        i[t.target.dataset.index].logistics_name = t.detail.value, that.setData({
            list: i
        });
    },
    numInput: function(t) {
        var i = that.data.list;
        i[t.target.dataset.index].logistics_no = t.detail.value, that.setData({
            list: i
        });
    },
    confirm: function(t) {
        var i = t.target.dataset.id, a = that.data.list, n = t.target.dataset.index;
        if ("" != a[n].logistics_name && a[n].logistics_name) if ("" != a[n].logistics_no && a[n].logistics_no) {
            var o = wx.getStorageSync("trd_session"), s = {};
            s.trd_session = o, s.id = i, s.logistics_name = a[n].logistics_name, s.logistics_no = a[n].logistics_no, 
            tools.requset("/Member/logistics", s, function(t) {
                1 == t.status && winnlist(that);
            });
        } else wx.showToast({
            title: "请输入快递单号",
            icon: "none",
            duration: 2e3
        }); else wx.showToast({
            title: "请输入物流公司",
            icon: "none",
            duration: 2e3
        });
    }
});
var tools = require("../../utils/tools.js");

function balance(e) {
    var t = wx.getStorageSync("trd_session");
    tools.requset("/Member/cash", {
        trd_session: t
    }, function(t) {
        e.setData({
            info: t.info
        });
    });
}

Page({
    data: {
        unitid: tools.unitid,
        show_adv: 2,
        adv: [],
        isshow:''
    },
    onLoad: function(t) {
        var e = this;
        getApp().tabhead(e), e.setData({
            headtxt: "我的"
        }), getApp().globalData.currTabFlag = "my";
        var a = getApp();
        getApp().editTabBar();
        var o = wx.getStorageSync("trd_session");
        tools.requset("?i=" + a.siteInfo.uniacid + "&c=entry&op=receive_card&do=my&m=" + a.modules_name + "&a=wxapp", {
            trd_session: o
        }, function(t) {
            1 == t.info.no_pic ? e.setData({
                getUserLyaer: !0
            }) : e.setData({
                userInfo: t.info
            });
        });
        var n = {
            trd_session: wx.getStorageSync("trd_session"),
            get_type: "my_a"
        };
        tools.requset("?i=" + a.siteInfo.uniacid + "&c=entry&op=receive_card&do=advertisement&m=" + a.modules_name + "&a=wxapp", n, function(t) {
            e.setData({
                show_adv: t.status
            }), 1 == t.status && (e.setData({
                adv_type: t.info.type,
                advertisement: t.info.advertisement
            }), e.data.adv = t.info.advertisement);
        });
        var h = {
          trd_session: wx.getStorageSync("trd_session")
        };
        tools.requset("?i=" + a.siteInfo.uniacid + "&c=entry&op=receive_card&do=me&m=" + a.modules_name + "&a=wxapp", h, function (t) {
          e.setData({
            isshow: t.info
          });
        });
    },
    onReady: function() {
        var t = getApp(), e = this, a = {
            trd_session: wx.getStorageSync("trd_session"),
            key: "red_bag"
        };
        tools.requset("?i=" + t.siteInfo.uniacid + "&c=entry&op=receive_card&do=config&m=" + t.modules_name + "&a=wxapp", a, function(t) {
            e.setData({
                red_bag: t.info
            });
        });
    },
    onShow: function() {},
    advjump: function(t) {
        var e = this;
        wx.navigateToMiniProgram({
            appId: e.data.adv.appId,
            path: e.data.adv.xcx_path,
            extraData: e.data.adv.extradata,
            success: function(t) {
                console.log("success");
            },
            fail: function(t) {
                wx.showModal({
                    title: "",
                    content: t.errMsg,
                    showCancel: !1
                });
            }
        });
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {},
    getUserInfo: function(t) {
        tools.userInfo(this, t);
    }
});
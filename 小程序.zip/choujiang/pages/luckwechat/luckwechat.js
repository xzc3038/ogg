var t, a = getApp(), e = require("../../utils/api.js"), s = [];
var tools = require("../../utils/tools.js"), QR = require("../../utils/qrcode.js"), WxParse = require("../../wxParse/wxParse.js"), touchDot = 0, touchend = 0;

Page({
  data: {
    programList: "",
    id: ''
  },
  onLoad: function (t) {
    var t = this, a = getApp(), s = {
      trd_session: wx.getStorageSync("trd_session")
    };
    tools.requset("?i=" + a.siteInfo.uniacid + "&c=entry&op=receive_card&do=program&m=" + a.modules_name + "&a=wxapp", s, function (e) {
      console.log(e.info)
      t.setData({
        programList: e.info
      });
    }), getApp().tabhead(t), t.setheight();
  },
  finishAndGetList: function (t, n) {
    var t = this;
    var id = t.data.id;
    a = getApp(), s = {
      trd_session: wx.getStorageSync("trd_session"),
      wid : id
    };
    tools.requset("?i=" + a.siteInfo.uniacid + "&c=entry&op=receive_card&do=wechat&m=" + a.modules_name + "&a=wxapp", s, function (e) {
      console.log(e.info);
      if(e.info.status == 1){
        wx.showToast({
          title: '查询小程序失败',
          icon: 'none'
        })
      }else if (e.info.status == 2){
        wx.showToast({
          title: '查询用户失败',
          icon: 'none'
        })
      } else if (e.info.status == 3) {
        wx.showToast({
          title: '更新记录失败',
          icon: 'none'
        })
      } else if (e.info.status == 4) {
        wx.showToast({
          title: '更新幸运币失败',
          icon: 'none'
        })
      } else if (e.info.status == 5) {
        wx.showToast({
          title: '更新点击失败',
          icon: 'none'
        })
      } else if (e.info.status == 6) {
        t.setData({
          programList: e.info.programList
        })
        wx.showToast({
          title: '领取成功，幸运币+' + e.info.coin,
          icon: 'none'
        })
      }
    })
  },
  taskSuccess: function (t) {
    var a = t.currentTarget.dataset.id;
    a?this.setData({
      id:a
    }):wx.showToast({
      title: '请重新尝试',
      icon: "none"
    })
    s = new Date().getTime(), wx.setStorageSync("jump", s);
    console.log(t);
  },
  onShow: function () {
      var t = this;
      var s = wx.getStorageSync("jump");
      console.log(s);
      if (s > 0) {
        var n = new Date().getTime();
        Number(n) - Number(s) >= 2e4 ? t.finishAndGetList() : wx.showToast({
          title: "体验20秒以上才有奖励哦~",
          icon: "none",
          duration: 1500
        }), wx.setStorageSync("jump", 0);
      }
  },
  onPullDownRefresh: function () {
    wx.stopPullDownRefresh();
  },
  setheight: function(){
    var t = this;
    wx.getSystemInfo({
      success: function (e) {
        -1 < e.model.indexOf("iPhone X") ? t.setData({
          height: 170
        }) : t.setData({
          height: 130
        });
      }
    });
  }
});
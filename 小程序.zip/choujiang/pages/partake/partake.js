var _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
    return typeof t;
} : function(t) {
    return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
};

function _defineProperty(t, e, a) {
    return e in t ? Object.defineProperty(t, e, {
        value: a,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : t[e] = a, t;
}

var tools = require("../../utils/tools.js"), QR = require("../../utils/qrcode.js"), WxParse = require("../../wxParse/wxParse.js"), touchDot = 0, touchend = 0;

function actDetail(a) {
    var t = wx.getStorageSync("trd_session"), e = _defineProperty({
        trd_session: t
    }, "trd_session", t);
    e.id = a.data.id, a.data.group_code && (e.group_code = a.data.group_code);
    var o = getApp();
    tools.requset("?i=" + o.siteInfo.uniacid + "&c=entry&op=receive_card&do=details&m=" + o.modules_name + "&a=wxapp", e, function(t) {
        if (t.info.condition == 1 || t.info.condition==2){
          a.setData({
            iscondition: !0
          });
          
          if (t.info.iscondition == 1 || t.info.iscondition == 2) {
            a.setData({
              isshowcondition: !1
            });
            wx.showToast({
              title: '不满足抽奖参与条件，返回首页参与更多抽奖',
              icon: "none"
            })
          }
        }
        
        a.setData({
          codeList:t.info.codeList
        });
        var e = t.info;
        a.data.member = e.member, 0 < e.max_group_num && e.group && (a.data.group_code = e.group.id, 
        a.setData({
            group_code: e.group.id
        })), 0 == e.desc_type && WxParse.wxParse("description_html", "html", e.description, a, 20), 
        a.setData({
            info: t.info
        }), 0 == e.status ? e.is_mine ? a.setData({
            state: 5
        }) : 0 == e.is_buy ? a.setData({
            state: 1
        }) : a.setData({
            state: 2
        }) : (a.setData({
            layer: !1
        }), 1 == e.is_cancel ? a.setData({
            state: 6
        }) : e.is_mine ? a.setData({
            state: 5
        }) : (wx.getStorageSync("status" + e.id) ? a.setData({
            layerones: !1
        }) : (a.setData({
            layerones: !0
        }), wx.setStorageSync("status" + e.id, !0)), 1 == e.is_winning ? (3 != e.my_in_prize[0].ptype && 0 != e.my_in_prize[0].ptype || (a.setData({
            qrcode: o.siteInfo.siteroot + "?i=" + o.siteInfo.uniacid + "&c=entry&op=receive_card&do=qrcode&m=" + o.modules_name + "&a=wxapp&code=" + e.my_in_prize[0].pvalue + "&resultid=" + e.my_in_prize[0].result_id
        }), a.createQrCode(e.my_in_prize[0].pvalue, "qrcCanvas", 180, 180)), a.setData({
            state: 3
        })) : a.setData({
            state: 4
        }))), 2 == a.data.state && a.setData({
            group_code: ""
        }), 0 != e.max_group_num || 0 != e.status || e.is_mine || 2 != a.data.state || (a.animation.translateX(-200).step(), 
        a.setData({
            animationData: a.animation.export()
        })), console.log(a.data.group_code);
    });
}

function timestampToTime(t) {
    var e = new Date(1e3 * t);
    return e.getFullYear() + "-" + ((e.getMonth() + 1 < 10 ? "0" + (e.getMonth() + 1) : e.getMonth() + 1) + "-") + (e.getDate() + " ") + (e.getHours() + ":") + (e.getMinutes() + ":") + (e.getSeconds() < 10 ? "0" + e.getSeconds() : e.getSeconds());
}

Page({
    data: {
        unitid: tools.unitid,
        shareLayer: !0,
        animationData: {},
        group_code: "",
        show_adv: 2,
        mycodelayer: !0,
        adv: [],
        member: [],
        member_id: 0,
        popup: [],
        popup_adv: 2,
        layer: !0,
        is_share: !1,
        command: "",
        reliefLayer: !1,
        relief_desc: "",
        wxpop: !1,
        wxpop: !1,
        isSave: !1,
        iscondition:!1,
        isshowcondition:!0
    },
    onLoad: function(t) {
        var e = this;
        getApp().tabhead(e), e.setData({
            is_share: e.data.is_share
        });
        var a = wx.createAnimation({
            duration: 1e3,
            timingFunction: "ease"
        });
        (e.animation = a).translateX(70).step(), e.setData({
            animationData: a.export()
        }), t.scene ? e.data.id = decodeURIComponent(t.scene) : e.data.id = t.id, t.group_code && (e.setData({
            group_code: t.group_code
        }), e.data.group_code = t.group_code), t.member_id && (e.data.member_id = t.member_id);
        var o = getApp(), i = {
            trd_session: wx.getStorageSync("trd_session")
        };
        tools.requset("?i=" + o.siteInfo.uniacid + "&c=entry&op=receive_card&do=author&m=" + o.modules_name + "&a=wxapp", i, function(t) {
            2 == t.status && e.setData({
                getUserLyaer: !0
            });
        }), o.globalData.userInfo ? e.setData({
            userInfo: o.globalData.userInfo
        }) : e.setData({
            getUserLyaer: !0
        });
        var n = {
            trd_session: wx.getStorageSync("trd_session"),
            key: "title,relief_desc,alipay_pwd"
        };
        tools.requset("?i=" + o.siteInfo.uniacid + "&c=entry&op=receive_card&do=configarr&m=" + o.modules_name + "&a=wxapp", n, function(t) {
            e.setData({
                headtxt: "抽奖详情",
                relief_desc: t.info.relief_desc
            }), "" != t.info.relief_desc && WxParse.wxParse("relief_desc_html", "html", t.info.relief_desc, e, 20), 
            "" != t.info.alipay_pwd;
        });
        n = {
            trd_session: wx.getStorageSync("trd_session"),
            get_type: "partake_a"
        };
        tools.requset("?i=" + o.siteInfo.uniacid + "&c=entry&op=receive_card&do=advertisement&m=" + o.modules_name + "&a=wxapp", n, function(t) {
            e.setData({
                show_adv: t.status
            }), 1 == t.status && (e.setData({
                adv_type: t.info.type,
                advertisement: t.info.advertisement
            }), e.data.adv = t.info.advertisement);
        }), tools.requset("?i=" + o.siteInfo.uniacid + "&c=entry&op=receive_card&do=popupadv&m=" + o.modules_name + "&a=wxapp", n, function(t) {
            e.setData({
                popup_adv: t.status
            }), 1 == t.status && (e.setData({
                popup: t.info
            }), e.data.popup = t.info);
        }), actDetail(e), getApp().globalData.currTabFlag = "partake", e.setData({
            currTabFlagVal: getApp().globalData.currTabFlag
        });
    },
    pagegoback: function() {
        wx.navigateTo({
            url: "../news/news"
        });
    },
    popupadvjump: function(t) {
        var e = this;
        wx.navigateToMiniProgram({
            appId: e.data.popup.appId,
            path: e.data.popup.xcx_path,
            extraData: e.data.popup.extradata,
            success: function(t) {
                console.log("success");
            },
            fail: function(t) {
                wx.showModal({
                    title: "",
                    content: t.errMsg,
                    showCancel: !1
                });
            }
        });
    },
    advjump: function(t) {
        var e = this;
        wx.navigateToMiniProgram({
            appId: e.data.adv.appId,
            path: e.data.adv.xcx_path,
            extraData: e.data.adv.extradata,
            success: function(t) {
                console.log("success");
            },
            fail: function(t) {
                wx.showModal({
                    title: "",
                    content: t.errMsg,
                    showCancel: !1
                });
            }
        });
    },
    createQrCode: function(t, e, a, o) {
        QR.api.draw(t, e, a, o);
    },
    morecode: function(t) {
        wx.navigateTo({
            url: "../allcode/allcode?id=" + this.data.id
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    command: function(t) {
        this.setData({
            command: t.detail.value
        });
    },
    onShareAppMessage: function(t) {
        var e = this, a = "";
        "" != e.data.userInfo.nickName ? a = e.data.userInfo.nickName + "给你发送了一个抽奖邀请,等你来抽" : e.data.info.uname && "" != e.data.info.uname ? a = e.data.info.uname + "给你发送了一个抽奖邀请，等你来抽" : e.data.info.wechat_no && "" != e.data.info.wechat_no && (a = e.data.info.wechat_no + "给你发送了一个抽奖邀请，等你来抽");
        var o = getApp(), i = o.siteInfo.siteroot + "?i=" + o.siteInfo.uniacid + "&c=entry&op=receive_card&do=share&m=" + o.modules_name + "&a=wxapp&id=" + e.data.id;
        return console.log(i), {
            title: a,
            imageUrl: i,
            path: "/pages/partake/partake?id=" + e.data.id + "&member_id=" + e.data.member.id
        };
    },
    getUserInfo: function(t) {
        tools.userInfo(this, t);
    },
    Invitation: function(t) {
        this.setData({
            shareLayer: !1
        });
    },
    showrelief: function(t) {
        this.setData({
            reliefLayer: !0
        });
    },
    closerelief: function(t) {
        this.setData({
            reliefLayer: !1
        });
    },
    cancelLayer: function(t) {
        this.setData({
            shareLayer: !0
        });
    },
    shareImg: function(t) {
        wx.navigateTo({
            url: "../shareImg/shareImg?id=" + this.data.id
        });
    },
    embed: function(t) {
        wx.navigateTo({
            url: "../embed/embed?id=" + this.data.id + "&purl=" + this.data.info.imgurl
        });
    },
    participate: function(e) {
        var a = this, t = e.detail.formId, o = wx.getStorageSync("trd_session"), i = {};
        i.trd_session = o, i.formid = t, i.id = a.data.id, i.group_code = a.data.group_code, 
        i.invitation_id = a.data.member_id, i.command = a.data.command;
        var n = getApp();
        tools.requset("?i=" + n.siteInfo.uniacid + "&c=entry&op=receive_card&do=apply&m=" + n.modules_name + "&a=wxapp", i, function(t)       {
            1 != t.status || a.data.group_code || (a.data.group_code = t.info), -1 != t.status ? "object" === _typeof(t.info) ? wx.requestPayment({
                timeStamp: t.info.timeStamp,
                nonceStr: t.info.nonceStr,
                package: t.info.package,
                signType: t.info.signType,
                paySign: t.info.paySign,
                success: function(t) {
                    a.participate(e);
                },
                fail: function(t) {
                    console.log(t);
                }
            }) : a.setData({
                succlayer: !0,
                succinfo: t.info
            }) : a.setData({
                getUserLyaer: !0
            });
      });
    },
    succlayerhidd: function(t) {
        this.setData({
            succlayer: !1
        }), actDetail(this);
    },
    lottery: function(t) {
        var e = this, a = t.detail.formId, o = {
            trd_session: wx.getStorageSync("trd_session"),
            formid: a,
            id: e.data.id
        }, i = getApp();
        tools.requset("?i=" + i.siteInfo.uniacid + "&c=entry&op=receive_card&do=openPrize&m=" + i.modules_name + "&a=wxapp", o, function(t) {
            actDetail(e);
        });
    },
    goindex: function(t) {
        wx.redirectTo({
            url: "../news/news"
        });
    },
    gofabu: function(t) {
        wx.redirectTo({
          url: "../first/first"
        });
    },
    address: function(t) {
        wx.navigateTo({
            url: "../address/address"
        });
    },
    layerhidden: function(t) {
        this.setData({
            layer: !0
        });
    },
    copy: function(t) {
        var e = t.currentTarget.dataset.name;
        wx.setClipboardData({
            data: e,
            success: function(t) {
                wx.showToast({
                    title: "复制成功！"
                });
            }
        });
    },
    more: function(t) {
        wx.navigateTo({
            url: "../list1/list?id=" + this.data.id
        });
    },
    all: function(t) {
        wx.navigateTo({
            url: "../list1/list?id=" + this.data.id + "&type=unwin"
        });
    },
    my_code: function(t) {
        var e = this, a = {}, o = wx.getStorageSync("trd_session");
        (a = _defineProperty({
            trd_session: o
        }, "trd_session", o)).id = e.data.id, a.ispage = 1;
        var i = getApp();
        tools.requset("?i=" + i.siteInfo.uniacid + "&c=entry&op=receive_card&do=code&m=" + i.modules_name + "&a=wxapp", a, function(t) {
            console.log(t);
            t = t.info;
            e.setData({
                usercodelist: t,
                mycodelayer: !1
            });
        });
    },
    codelayerclose: function(t) {
        this.setData({
            mycodelayer: !0
        });
    },
    seewinnlist: function(t) {
        wx.navigateTo({
            url: "../winnlist/winnlist?id=" + this.data.id
        });
    },
    touchStart: function(t) {
        touchDot = t.touches[0].pageX;
    },
    touchMove: function(t) {
        var e = t.touches[0].pageX;
        touchend = e - touchDot;
    },
    touchEnd: function(t) {
        touchend < -100 && this.animation.translateX(-200).step(), 60 < touchend && this.animation.translateX(70).step(), 
        this.setData({
            animationData: this.animation.export()
        });
    },
    groupBtn: function(t) {
        var e = this, a = wx.getStorageSync("trd_session"), o = {};
        o.prize_id = e.data.id, o.trd_session = a, tools.requset("/Member/createGroup", o, function(t) {
            wx.navigateTo({
                url: "../share/share?id=" + e.data.id
            });
        });
    },
    goshare: function(t) {
        wx.navigateTo({
            url: "../share/share?id=" + this.data.id
        });
    },
    groupjoin: function(t) {
        var e = this, a = wx.getStorageSync("trd_session"), o = {};
        o.group_code = e.data.group_code, o.trd_session = a, tools.requset("/Member/joinGroup", o, function(t) {
            actDetail(e);
        });
    },
    voucher: function() {
        wx.navigateTo({
            url: "../voucher/voucher"
        });
    },
    show_qr: function(){
      this.setData({
        wxpop: !0
      })
    },
  addView: function (t) { },
  saveImg: function (o) {
    var e = this,t = getApp();
    e.setData({
      wxpop: !1
    }), wx.getSetting({
      success: function (t) {
        console.log(t.authSetting), t.authSetting["scope.writePhotosAlbum"] ? e.saveImage() : 0 == t.authSetting["scope.writePhotosAlbum"] ? e.setData({
          wxpop: !1,
          isSave: !0
        }) : e.saveImage();
      },
      fail: function (t) {
        wx.showToast({
          title: "保存失败",
          icon: "none",
          duration: 2e3
        });
      }
    });
  },
  saveImage: function (t) {
    wx.getImageInfo({
      src: this.data.info.jump_info.wechatImg,
      success: function (t) {
        wx.saveImageToPhotosAlbum({
          filePath: t.path,
          success: function (t) {
            wx.showToast({
              title: "保存成功",
              icon: "success",
              duration: 2e3
            });
          }
        });
      },
      fail: function (t) {
        console.log(t), wx.showToast({
          title: "保存失败",
          icon: "none",
          duration: 2e3
        });
      }
    });
  },
  popSet: function (t) {
    this.setData({
      isSave: !1
    });
  },
  popCancel1: function (t) {
    this.setData({
      wxpop: !1,
      isSave: !1
    });
  },
  copyWx: function (o) {
     wx.setClipboardData({
      data: "zm888779",
      success: function (t) {
        wx.getClipboardData({
          success: function (t) { }
        });
      }
    });
  }
});
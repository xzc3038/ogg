function _defineProperty(e, a, t) {
    return a in e ? Object.defineProperty(e, a, {
        value: t,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[a] = t, e;
}
var t, s, e, a, d, i, n, o, r, u = getApp(),l='';
var address = require("../../utils/city.js"), tools = require("../../utils/tools.js");

function getAddress(a) {
    var e = getApp(), t = wx.getStorageSync("trd_session");
    tools.requset("?i=" + e.siteInfo.uniacid + "&c=entry&op=receive_card&do=getAddress&m=" + e.modules_name + "&a=wxapp", _defineProperty({
        trd_session: t
    }, "trd_session", t), function(e) {
        "" == (e = e.info).name ? wx.chooseAddress({
            success: function(e) {
                console.log(e.userName), console.log(e.postalCode), console.log(e.provinceName), 
                console.log(e.cityName), console.log(e.countyName), console.log(e.detailInfo), console.log(e.nationalCode), 
                console.log(e.telNumber), a.setData({
                    consignee: e.userName,
                    tel: e.telNumber,
                    detailAddress: e.provinceName + e.cityName + e.countyName + e.detailInfo,
                    nameandphone: e.userName + '   ' + e.telNumber
                });
            }
        }) : a.setData({
            consignee: e.name,
            tel: e.phone,
            detailAddress: e.address,
            nameandphone: e.name + '   ' + e.phone
        });
    });
}

Page({
    data: {
        isAddress:!1,
        detailAddress: "",
        nameandphone:''
    },
    onLoad: function(e) {
        var a = this;
        getApp().tabhead(a), this.setData({
            headtxt: "地址管理"
        });
        var t = wx.createAnimation({
            duration: 500,
            transformOrigin: "50% 50%",
            timingFunction: "ease"
        });
        this.animation = t;
        var s = address.provinces[0].id;
        this.setData({
            provinces: address.provinces,
            citys: address.citys[s],
            areas: address.areas[address.citys[s][0].id]
        }), getAddress(a), a.setData({
            currTabFlagVal: getApp().globalData.currTabFlag
        });
    },
    pagegoback: function() {
        wx.navigateBack({
            delta: 1
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {},
    getAddress: function (t) {
      var s = this;
      wx.getSetting({
        success: function (t) {
          "{}" != JSON.stringify(t.authSetting) ? t.authSetting["scope.address"] ? s.getAddData() : 0 == t.authSetting["scope.address"] ? s.setData({
            isAddress: !0
          }) : s.getAddData() : s.getAddData();
        },
        fail: function (t) {
          wx.showToast({
            title: "保存失败",
            icon: "none",
            duration: 2e3
          });
        }
      });
    },
    getAddData: function (t) {
      var u = this;
      wx.chooseAddress({
        success: function (t) {
          s = t.userName, e = t.postalCode, a = t.provinceName, d = t.cityName, i = t.countyName,
            n = t.detailInfo, o = t.nationalCode, r = t.telNumber, l =  a + d + i + n,
            u.setData({
              detailAddress: l,
              tel:r,
              consignee:s,
              nameandphone: r + '   ' + s
            });
        }
      });
    },
    popSet: function (t) {
      this.setData({
        isAddress: !1
      });
    },
    popCancel: function (t) {
      this.setData({
        isAddress: !1
      });
    },
    popCancel1: function (t) {
      this.setData({
        isAddress: !1
      });
    },
    submit: function(e) {
        var a = this, t = {}, s = wx.getStorageSync("trd_session"), i = a.data.consignee, n = a.data.tel, o = a.data.detailAddress;
        if ("" != i) if ("" != n) if ("" != o) {
            t.trd_session = s, t.formid = e.detail.formId, t.name = i, t.phone = n, t.address = o;
            var d = getApp();
            tools.requset("?i=" + d.siteInfo.uniacid + "&c=entry&op=receive_card&do=address&m=" + d.modules_name + "&a=wxapp", t, function(e) {
                // console.log(e.info), wx.navigateBack();
                if(e.info == 'ok'){
                  wx.showToast({
                    title:'保存成功',
                    icon:'success'
                  })
                }
            });
        } else tools.showNotice("请填写详细地址"); else tools.showNotice("请填写电话"); else tools.showNotice("请填写收货人");
    }
});
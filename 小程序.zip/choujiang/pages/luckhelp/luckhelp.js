getApp();

Page({
  data:{},
  onLoad:function(){
    getApp().tabhead(this)
  }
});
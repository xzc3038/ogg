function _defineProperty(t, a, e) {
  return a in t ? Object.defineProperty(t, a, {
    value: e,
    enumerable: !0,
    configurable: !0,
    writable: !0
  }) : t[a] = e, t;
}

var that, tools = require("../../utils/tools.js");

function imlist(a) {
  var t = {}, e = wx.getStorageSync("trd_session");
  t.trd_session = e, t.id = a.data.id, t.p = a.data.p, t.type = a.data.type;
  var o = getApp();
  tools.requset("?i=" + o.siteInfo.uniacid + "&c=entry&op=receive_card&do=all&m=" + o.modules_name + "&a=wxapp", t, function (t) {
    console.log(t);
    t = t.info;
    1 < a.data.p && (t = a.data.info.concat(t)), a.setData({
      info: t
    });
  });
}

Page({
  data: {
    layer: !0,
    p: 1,
    p2: 1,
    show_type: 0,
    show_adv: 2,
    adv: [],
    user_totals: 0
  },
  onLoad: function (t) {
    that = this, t.id && (that.data.id = t.id), that.setData({
      headtxt: "抽奖参与用户"
    }), getApp().tabhead(that), imlist(that);
    var a = getApp(), e = {
      trd_session: wx.getStorageSync("trd_session"),
      id: that.data.id,
      key: "list_show_type,show_user_totals"
    };
    tools.requset("?i=" + a.siteInfo.uniacid + "&c=entry&op=receive_card&do=configarr&m=" + a.modules_name + "&a=wxapp", e, function (t) {
      that.setData({
        show_type: t.info.list_show_type,
        user_totals: t.info.show_user_totals
      });
    });
    e = {
      trd_session: wx.getStorageSync("trd_session"),
      get_type: "list_a"
    };
    tools.requset("?i=" + a.siteInfo.uniacid + "&c=entry&op=receive_card&do=advertisement&m=" + a.modules_name + "&a=wxapp", e, function (t) {
      that.setData({
        show_adv: t.status
      }), 1 == t.status && (that.setData({
        adv_type: t.info.type,
        advertisement: t.info.advertisement
      }), that.data.adv = t.info.advertisement);
    }), getApp().globalData.currTabFlag = "my", that.setData({
      currTabFlagVal: getApp().globalData.currTabFlag
    });
  },
  pagegoback: function () {
    wx.navigateBack({
      delta: 1
    });
  },
  advjump: function (t) {
    var a = this;
    wx.navigateToMiniProgram({
      appId: a.data.adv.appId,
      path: a.data.adv.xcx_path,
      extraData: a.data.adv.extradata,
      success: function (t) {
        console.log("success");
      },
      fail: function (t) {
        wx.showModal({
          title: "",
          content: t.errMsg,
          showCancel: !1
        });
      }
    });
  },
  onReady: function () { },
  onShow: function () { },
  onHide: function () { },
  onUnload: function () { },
  onPullDownRefresh: function () { },
  onReachBottom: function () {
    that.data.p += 1, imlist(that);
  },
  onShareAppMessage: function () { },
  detail: function (t) {
    that.data.p2 = 1;
    var a = t.currentTarget.dataset.id, e = {}, o = wx.getStorageSync("trd_session");
    (e = _defineProperty({
      trd_session: o
    }, "trd_session", o)).member_id = a, e.id = that.data.id, e.p = that.data.p2;
    var s = getApp();
    tools.requset("?i=" + s.siteInfo.uniacid + "&c=entry&op=receive_card&do=code&m=" + s.modules_name + "&a=wxapp", e, function (t) {
      console.log(t);
      t = t.info;
      1 < that.data.p2 && (t = that.data.usercodelist.concat(t)), that.setData({
        usercodelist: t,
        layer: !1,
        member_id: a
      });
    });
  },
  colose: function (t) {
    that.setData({
      layer: !0
    });
  },
  more: function (t) {
    that.data.p2 += 1;
    var a = that.data.member_id, e = {}, o = wx.getStorageSync("trd_session");
    (e = _defineProperty({
      trd_session: o
    }, "trd_session", o)).member_id = a, e.id = that.data.id, e.p = that.data.p2;
    var s = getApp();
    tools.requset("?i=" + s.siteInfo.uniacid + "&c=entry&op=receive_card&do=code&m=" + s.modules_name + "&a=wxapp", e, function (t) {
      console.log(t);
      t = t.info;
      1 < that.data.p2 && (t = that.data.usercodelist.concat(t)), that.setData({
        usercodelist: t
      });
    });
  }
});
var tools = require("../../utils/tools.js");

function getProblem(a) {
    var t = getApp(), e = wx.getStorageSync("trd_session");
    tools.requset("?i=" + t.siteInfo.uniacid + "&c=entry&op=receive_card&do=problem&m=" + t.modules_name + "&a=wxapp", {
        trd_session: e
    }, function(t) {
        a.setData({
            list: t.info
        });
    });
}

Page({
    data: {
        headtxt: "问题",
        unitid: tools.unitid,
        show_adv: 2,
        adv: []
    },
    onLoad: function(t) {
        var a = this;
        getApp().tabhead(a), getProblem(a), a.setData({
            currTabFlagVal: getApp().globalData.currTabFlag
        });
    },
    pagegoback: function() {
        wx.navigateBack({
            delta: 1
        });
    },
    expandMenu: function(t) {
        var a = this, e = t.currentTarget.dataset.index;
        a.data.list[e].hidden = !a.data.list[e].hidden, a.setData({
            list: a.data.list
        });
    },
    onReady: function() {
        var a = this, t = getApp(), e = {
            trd_session: wx.getStorageSync("trd_session"),
            get_type: "problem_a"
        };
        tools.requset("?i=" + t.siteInfo.uniacid + "&c=entry&op=receive_card&do=advertisement&m=" + t.modules_name + "&a=wxapp", e, function(t) {
            a.setData({
                show_adv: t.status
            }), console.log(t.info.advertisement), 1 == t.status && (a.setData({
                adv_type: t.info.type,
                advertisement: t.info.advertisement
            }), a.data.adv = t.info.advertisement);
        });
    },
    onShow: function() {},
    advjump: function(t) {
        var a = this;
        wx.navigateToMiniProgram({
            appId: a.data.adv.appId,
            path: a.data.adv.xcx_path,
            extraData: a.data.adv.extradata,
            success: function(t) {
                console.log("success");
            },
            fail: function(t) {
                wx.showModal({
                    title: "",
                    content: t.errMsg,
                    showCancel: !1
                });
            }
        });
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {},
    show: function(t) {
        var a = t.currentTarget.dataset.id;
        this.setData({
            anser: a
        });
    }
});
var tools = require("../../utils/tools.js");

function list(o) {
    var t = getApp(), n = wx.getStorageSync("trd_session");
    tools.requset("?i=" + t.siteInfo.uniacid + "&c=entry&op=receive_card&do=jump&m=" + t.modules_name + "&a=wxapp", {
        trd_session: n
    }, function(t) {
        console.log(t), o.setData({
            list: t.info
        });
    });
}

Page({
    data: {},
    onLoad: function(t) {
        var o = this, n = getApp(), e = {
            trd_session: wx.getStorageSync("trd_session"),
            key: "title"
        };
        tools.requset("?i=" + n.siteInfo.uniacid + "&c=entry&op=receive_card&do=config&m=" + n.modules_name + "&a=wxapp", e, function(t) {
            o.setData({
                headtxt: t.info ? t.info : "抽奖小助手"
            });
        }), getApp().tabhead(o), list(o), o.setData({
            currTabFlagVal: getApp().globalData.currTabFlag
        });
    },
    pagegoback: function() {
        wx.navigateBack({
            delta: 1
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {},
    jump: function(t) {
        var o = t.currentTarget.dataset.appid;
        wx.navigateToMiniProgram({
            appId: o,
            success: function(t) {
                console.log("success");
            },
            fail: function(t) {
                wx.showModal({
                    title: "",
                    content: t.errMsg,
                    showCancel: !1
                });
            }
        });
    }
});
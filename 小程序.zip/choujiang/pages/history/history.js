function _defineProperty(t, a, e) {
    return a in t ? Object.defineProperty(t, a, {
        value: e,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : t[a] = e, t;
}

var tools = require("../../utils/tools.js");

function myLaunch(e) {
    var t = wx.getStorageSync("trd_session"), a = _defineProperty({
        trd_session: t
    }, "trd_session", t);
    a.p = e.data.p1;
    var n = getApp();
    tools.requset("?i=" + n.siteInfo.uniacid + "&c=entry&op=receive_card&do=launch&m=" + n.modules_name + "&a=wxapp", a, function(t) {
        t = t.info;
        console.log(t);
        for (var a = 0; a < t.length; a++) t[a].addtime = timestampToTime(t[a].created);
        e.setData({
            lucklist: t,
            noData: !1
        });
    });
}

function myPart(e, t) {
    var a = wx.getStorageSync("trd_session"), n = _defineProperty({
        trd_session: a
    }, "trd_session", a);
    n.p = e.data.p2, n.status = t;
    var o = getApp();
    tools.requset("?i=" + o.siteInfo.uniacid + "&c=entry&op=receive_card&do=history&m=" + o.modules_name + "&a=wxapp", n, function(t) {
        t = t.info;
        console.log(t);
        for (var a = 0; a < t.length; a++) t[a].addtime = timestampToTime(t[a].addtime);
        e.setData({
            lucklist: t,
            noData: !1
        });
    });
}

function timestampToTime(t) {
    var a = new Date(1e3 * t);
    return a.getFullYear() + "-" + ((a.getMonth() + 1 < 10 ? "0" + (a.getMonth() + 1) : a.getMonth() + 1) + "-") + (a.getDate() + " ") + (a.getHours() + ":") + (a.getMinutes() + ":") + (a.getSeconds() < 10 ? "0" + a.getSeconds() : a.getSeconds());
}

Page({
    data: {
        unitid: tools.unitid,
        headtxt: "历史",
        navOn: 2,
        p1: 1,
        p2: 1,
        show_adv: 2,
        adv: []
    },
    onLoad: function(t) {
        var a = this;
        this.setData({
            headtxt: "我参与的"
        }), getApp().tabhead(a), myPart(a, 2), a.setData({
            currTabFlagVal: getApp().globalData.currTabFlag
        });
    },
    pagegoback: function() {
        wx.navigateBack({
            delta: 1
        });
    },
    onReady: function() {
        var a = this, t = getApp(), e = {
            trd_session: wx.getStorageSync("trd_session"),
            get_type: "history_a"
        };
        tools.requset("?i=" + t.siteInfo.uniacid + "&c=entry&op=receive_card&do=advertisement&m=" + t.modules_name + "&a=wxapp", e, function(t) {
            a.setData({
                show_adv: t.status
            }), 1 == t.status && (a.setData({
                adv_type: t.info.type,
                advertisement: t.info.advertisement
            }), a.data.adv = t.info.advertisement);
        });
    },
    advjump: function(t) {
        var a = this;
        wx.navigateToMiniProgram({
            appId: a.data.adv.appId,
            path: a.data.adv.xcx_path,
            extraData: a.data.adv.extradata,
            success: function(t) {
                console.log("success");
            },
            fail: function(t) {
                wx.showModal({
                    title: "",
                    content: t.errMsg,
                    showCancel: !1
                });
            }
        });
    },
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {},
    navSwitch: function(t) {
        var a = this, e = t.currentTarget.dataset.id;
        a.data.navOn != e && (a.setData({
            lucklist: [],
            noData: !0
        }), a.setData({
            navOn: e
        }), myPart(a, e));
    },
    detail: function(t) {
        var a = t.currentTarget.dataset.id;
        wx.navigateTo({
            url: "../partake/partake?id=" + a
        });
    }
});
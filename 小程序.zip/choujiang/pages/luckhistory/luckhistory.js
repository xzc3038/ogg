var tools = require("../../utils/tools.js"), QR = require("../../utils/qrcode.js"), WxParse = require("../../wxParse/wxParse.js"), touchDot = 0, touchend = 0;

Page({
  data: {
    history: '',
    total:!1
  },
  onLoad: function (t) {
    var t = this, a = getApp(), s = {
      trd_session: wx.getStorageSync("trd_session")
    };
    tools.requset("?i=" + a.siteInfo.uniacid + "&c=entry&op=receive_card&do=luckhistory&m=" + a.modules_name + "&a=wxapp", s, function (e) {
      console.log(e.info);
      if (e.info.total == 1){
        t.setData({
          total:!1,
          history: e.info.history
        });
      }else{
        t.setData({
          total: !0,
          history: e.info.history
        });
      }
      
    }), getApp().tabhead(t);
  }
});
var _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
    return typeof t;
} : function(t) {
    return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
};

function _defineProperty(t, e, a) {
    return e in t ? Object.defineProperty(t, e, {
        value: a,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : t[e] = a, t;
}

var tools = require("../../utils/tools.js"), touchDot = 0, touchend = 0;

function actDetail(c) {
    var t = wx.getStorageSync("trd_session"), e = {};
    e.trd_session = t, e.id = c.data.id, c.data.group_code && (e.group_code = c.data.group_code), 
    tools.requset("/Member/detail", e, function(t) {
        console.log(t.info);
        var e = t.info;
        e.type;
        for (var a = [], o = [], i = [], n = "", s = "", r = "", d = 0; d < e.results.length; d++) "fir" == e.results[d].type && (n = e.results[d].prize_name, 
        a.push(e.results[d])), "sec" == e.results[d].type && (s = e.results[d].prize_name, 
        o.push(e.results[d])), "trd" == e.results[d].type && (r = e.results[d].prize_name, 
        i.push(e.results[d]));
        0 == e.status ? 0 == e.is_buy ? c.setData({
            state: 1
        }) : c.setData({
            state: 2
        }) : 1 == e.is_cancel ? c.setData({
            state: 6
        }) : (wx.getStorageSync("status" + e.prize_id) ? c.setData({
            layerones: !1
        }) : (c.setData({
            layerones: !0
        }), wx.setStorageSync("status" + e.prize_id, !0)), 1 == e.is_winning ? c.setData({
            state: 3
        }) : c.setData({
            state: 4
        })), 2 == c.data.state && c.setData({
            group_code: ""
        }), 0 != e.status || e.is_mine || 2 != c.data.state || (c.animation.translateX(-200).step(), 
        c.setData({
            animationData: c.animation.export()
        })), c.setData({
            info: t.info,
            firarry: a,
            secarry: o,
            trdarry: i,
            firgoods: n,
            secgoods: s,
            trdgoods: r,
            layer: !1
        });
    });
}

function addetail(t) {
    var e = wx.getStorageSync("trd_session");
    tools.requset("/Index/ad", {
        trd_session: e
    }, function(t) {});
}

function timestampToTime(t) {
    var e = new Date(1e3 * t);
    return e.getFullYear() + "-" + ((e.getMonth() + 1 < 10 ? "0" + (e.getMonth() + 1) : e.getMonth() + 1) + "-") + (e.getDate() < 10 ? "0" + e.getDate() : e.getDate()) + " " + (e.getHours() + ":") + (e.getMinutes() < 10 ? "0" + e.getMinutes() : e.getMinutes()) + ":" + (e.getSeconds() < 10 ? "0" + e.getSeconds() : e.getSeconds());
}

Page({
    data: {
        unitid: tools.unitid,
        layer: !0,
        shareLayer: !0,
        mycodelayer: !0,
        animationData: {},
        group_code: ""
    },
    onLoad: function(t) {
        var e = this, a = wx.createAnimation({
            duration: 1e3,
            timingFunction: "ease"
        });
        if ((e.animation = a).translateX(70).step(), e.setData({
            animationData: a.export()
        }), console.log(t.scene), t.scene) {
            var o = t.scene;
            if (isNaN(o)) {
                var i = o.split("_");
                e.data.id = i[0], e.data.member_id = i[1];
            } else e.data.id = o;
        } else e.data.id = t.id;
        t.group_code && e.setData({
            group_code: t.group_code
        }), t.member_id && (e.data.member_id = t.member_id);
        var n = wx.getStorageSync("trd_session");
        tools.requset("/Member/minfo", {
            trd_session: n
        }, function(t) {
            1 == t.info.no_pic ? e.setData({
                getUserLyaer: !0
            }) : e.setData({
                userInfo: t.info
            });
        }), actDetail(e);
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function(t) {
        var e = this, a = "";
        return a = "yaoqings" == t.target.dataset.id ? "/pages/partake/partake?id=" + e.data.id : "/pages/partake/partake?member_id=" + e.data.userInfo.member_id + "&id=" + e.data.id, 
        {
            title: "邀请您参加[" + e.data.info.fir_val + "]抽奖",
            imageUrl: e.data.info.share_sub_url || "",
            path: a
        };
    },
    getUserInfo: function(t) {
        tools.userInfo(this, t);
    },
    Invitation: function(t) {
        this.setData({
            shareLayer: !1
        });
    },
    cancelLayer: function(t) {
        this.setData({
            shareLayer: !0
        });
    },
    shareImg: function(t) {
        wx.navigateTo({
            url: "../shareImg/shareImg?member_id=" + this.data.userInfo.member_id + "&id=" + this.data.id
        });
    },
    embed: function(t) {
        wx.navigateTo({
            url: "../embed/embed?id=" + this.data.id
        });
    },
    participate: function(e) {
        var a = this;
        if (0 != a.data.info.is_check) {
            var t = e.detail.formId, o = wx.getStorageSync("trd_session"), i = {};
            i.trd_session = o, i.formid = t, i.id = a.data.id, a.data.member_id && (i.share_member_id = a.data.member_id), 
            tools.requset("/Member/buy", i, function(t) {
                "object" === _typeof(t.info) ? wx.requestPayment({
                    timeStamp: t.info.timeStamp,
                    nonceStr: t.info.nonceStr,
                    package: t.info.package,
                    signType: t.info.signType,
                    paySign: t.info.paySign,
                    success: function(t) {
                        a.participate(e);
                    },
                    fail: function(t) {
                        console.log(t);
                    }
                }) : a.setData({
                    succlayer: !0,
                    succinfo: t.info
                });
            });
        } else wx.showToast({
            title: "请等待审核",
            icon: "none",
            duration: 2e3
        });
    },
    succlayerhidd: function(t) {
        this.setData({
            succlayer: !1
        }), actDetail(this);
    },
    lottery: function(t) {
        var e = this, a = t.detail.formId, o = {
            trd_session: wx.getStorageSync("trd_session"),
            formid: a,
            id: e.data.id
        };
        tools.requset("/Member/openPrize", o, function(t) {
            actDetail(e);
        });
    },
    goindex: function(t) {
        wx.redirectTo({
            url: "../news/news"
        });
    },
    gofabu: function(t) {
        wx.redirectTo({
            url: "../index/index"
        });
    },
    address: function(t) {
        wx.navigateTo({
            url: "../address/address?id=" + this.data.id
        });
    },
    layerhidden: function(t) {
        this.setData({
            layer: !0
        });
    },
    copy: function(t) {
        var e = t.currentTarget.dataset.name;
        wx.setClipboardData({
            data: e,
            success: function(t) {
                wx.showToast({
                    title: "复制成功！"
                });
            }
        });
    },
    more: function(t) {
        wx.navigateTo({
            url: "../list/list?id=" + this.data.id
        });
    },
    all: function(t) {
        wx.navigateTo({
            url: "../all/all?id=" + this.data.id + "&type=unwin"
        });
    },
    jumpUp: function(t) {
        var e = this, a = wx.getStorageSync("trd_session");
        tools.requset("/Prize/miniClick", {
            trd_session: a,
            pos: "up",
            id: e.data.id
        }, function(t) {
            wx.navigateToMiniProgram({
                appId: e.data.info.jump_info.appid,
                path: e.data.info.jump_info.path,
                extraData: e.data.info.jump_info.extradata,
                success: function(t) {
                    console.log("success");
                },
                fail: function(t) {
                    wx.showModal({
                        title: "",
                        content: t.errMsg,
                        showCancel: !1
                    });
                }
            });
        });
    },
    jumpDown: function(t) {
        var e = this, a = wx.getStorageSync("trd_session");
        tools.requset("/Prize/miniClick", {
            trd_session: a,
            pos: "down",
            id: e.data.id
        }, function(t) {
            wx.navigateToMiniProgram({
                appId: e.data.info.jump_info.appid,
                path: e.data.info.jump_info.path,
                extraData: e.data.info.jump_info.extradata,
                success: function(t) {
                    console.log("success");
                },
                fail: function(t) {
                    wx.showModal({
                        title: "",
                        content: t.errMsg,
                        showCancel: !1
                    });
                }
            });
        });
    },
    jump2: function(t) {
        var e = this, a = wx.getStorageSync("trd_session");
        tools.requset("/Index/ad", {
            trd_session: a,
            id: e.data.info.ad.ad_id
        }, function(t) {
            wx.navigateToMiniProgram({
                appId: e.data.info.ad.appid,
                path: e.data.info.ad.path,
                extraData: e.data.info.ad.extradata,
                success: function(t) {
                    console.log("success");
                },
                fail: function(t) {
                    wx.showModal({
                        title: "",
                        content: t.errMsg,
                        showCancel: !1
                    });
                }
            });
        });
    },
    touchStart: function(t) {
        touchDot = t.touches[0].pageX;
    },
    touchMove: function(t) {
        var e = t.touches[0].pageX;
        touchend = e - touchDot;
    },
    touchEnd: function(t) {
        console.log(touchend);
        touchend < -100 && this.animation.translateX(-200).step(), 60 < touchend && this.animation.translateX(70).step(), 
        this.setData({
            animationData: this.animation.export()
        });
    },
    groupBtn: function(t) {
        var e = this, a = wx.getStorageSync("trd_session"), o = {};
        o.prize_id = e.data.id, o.trd_session = a, tools.requset("/Member/createGroup", o, function(t) {
            wx.navigateTo({
                url: "../share/share?id=" + e.data.id
            });
        });
    },
    goshare: function(t) {
        wx.navigateTo({
            url: "../share/share?id=" + this.data.id
        });
    },
    groupjoin: function(t) {
        var e = this, a = wx.getStorageSync("trd_session"), o = {};
        o.group_code = e.data.group_code, o.trd_session = a, tools.requset("/Member/joinGroup", o, function(t) {
            actDetail(e);
        });
    },
    my_code: function(t) {
        var e = this, a = e.data.userInfo.member_id, o = {}, i = wx.getStorageSync("trd_session");
        (o = _defineProperty({
            trd_session: i
        }, "trd_session", i)).member_id = a, o.id = e.data.id, tools.requset("/Prize/usercodelist", o, function(t) {
            console.log(t);
            t = t.info;
            e.setData({
                usercodelist: t,
                mycodelayer: !1
            });
        });
    },
    codelayerclose: function(t) {
        this.setData({
            mycodelayer: !0
        });
    },
    morecode: function(t) {
        wx.navigateTo({
            url: "../allcode/allcode?id=" + that.data.id
        });
    },
    edit: function(t) {
        wx.navigateTo({
            url: "../edit/edit?id=" + this.data.id
        });
    },
    seewinnlist: function(t) {
        wx.navigateTo({
            url: "../winnlist/winnlist?id=" + this.data.id
        });
    },
    mymin: function(t) {
        wx.redirectTo({
            url: "../my/my"
        });
    }
});
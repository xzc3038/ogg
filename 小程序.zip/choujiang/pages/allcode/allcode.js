var tools = require("../../utils/tools.js");

function imlist(t) {
    var o = wx.getStorageSync("trd_session"), n = {};
    n.trd_session = o, n.id = t.data.id;
    var i = getApp();
    tools.requset("?i=" + i.siteInfo.uniacid + "&c=entry&op=receive_card&do=allcode&m=" + i.modules_name + "&a=wxapp", n, function(o) {
        console.log(o), t.setData({
            list: o.info
        });
    });
}

Page({
    data: {},
    onLoad: function(o) {
        var t = this;
        getApp().tabhead(t), this.setData({
            headtxt: "抽奖码"
        }), o.id && (t.data.id = o.id), imlist(t);
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});
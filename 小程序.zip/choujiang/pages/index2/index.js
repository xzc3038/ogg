var _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
    return typeof e;
} : function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
}, _weCropperMin = require("../../utils/dist/weCropper.min.js"), _weCropperMin2 = _interopRequireDefault(_weCropperMin);

function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

var dateTimePicker = require("../../utils/dateTimePicker.js"), app = getApp(), tools = require("../../utils/tools.js"), device = wx.getSystemInfoSync(), max_group_num = 0, upload_status = !1;

function voucher(e, t, a) {}

Page({
    data: {
        unitid: tools.unitid,
        crop: !1,
        isshow: !1,
        setArray: [ {
            prIndex: 0,
            num: 1,
            money: "",
            prize: "",
            cardname: "",
            cardmsg: ""
        } ],
        conIndex: 0,
        conArray: [ "人数开奖", "时间开奖", "手动开奖" ],
        expIndex: 1,
        explainArray: [ "文字", "图片" ],
        startTime: "请选择时间",
        awardsNum: 1,
        remarks: "",
        remarksImg: "",
        jdexplain: "",
        jdnum: 0,
        cjnum: 0,
        business: "",
        copyorjump: 1,
        copyname: "",
        isgroup: !1,
        max_group_num: 0,
        wechat_title: "",
        is_share: 0,
        is_command: 0,
        command: "",
        close_cmd_prize: 0,
        cmd_prize_label: "",
        bgimg: "https://www.we8cc.com/we8/addons/hu_couda/loading.gif",
        cropperOpt: {
            id: "cropper",
            width: device.windowWidth,
            height: device.windowWidth / 630 * 320,
            scale: 2.5,
            zoom: 8
        },
        height: device.windowHeight,
        fir_ptype: 0,
        fir_num: "",
        fir_val: "",
        sec_ptype: 0,
        sec_num: "",
        sec_val: "",
        trd_ptype: 0,
        trd_num: "",
        trd_val: "",
        attach_id: "",
        choiceindex: "",
        is_voucher: 2,
        red_bag: 0,
        voucher_open: 0,
        red_package_fee: 0,
        is_release: 0,
        show_adv: 2,
        adv: [],
        isjump: 1,
        hasImg:!0,
        isshowcondition:!1,
        condition:1
    },
    onLoad: function(e) {
        getApp().editTabBar();
        var t = this, a = getApp(), s = {
            trd_session: wx.getStorageSync("trd_session"),
            key: "title"
        };
        getApp().globalData.currTabFlag = "index", tools.requset("?i=" + a.siteInfo.uniacid + "&c=entry&op=receive_card&do=config&m=" + a.modules_name + "&a=wxapp", s, function(e) {
            t.setData({
                headtxt: e.info ? e.info : "高级版"
            });
        });
        var n = {
            trd_session: wx.getStorageSync("trd_session")
        };
        tools.requset("?i=" + a.siteInfo.uniacid + "&c=entry&op=receive_card&do=author&m=" + a.modules_name + "&a=wxapp", n, function(e) {
            2 == e.status && t.setData({
                getUserLyaer: !0
            });
        });
        s = {
            trd_session: wx.getStorageSync("trd_session"),
            key: "home_recommendation"
        };
        tools.requset("?i=" + a.siteInfo.uniacid + "&c=entry&op=receive_card&do=config&m=" + a.modules_name + "&a=wxapp", s, function(e) {
            t.setData({
                home_recommendation: e.info ? e.info : 0
            });
        });
        s = {
            trd_session: wx.getStorageSync("trd_session"),
            get_type: "index_a"
        };
        tools.requset("?i=" + a.siteInfo.uniacid + "&c=entry&op=receive_card&do=advertisement&m=" + a.modules_name + "&a=wxapp", s, function(e) {
            t.setData({
                show_adv: e.status
            }), 1 == e.status && (t.setData({
                adv_type: e.info.type,
                advertisement: e.info.advertisement
            }), t.data.adv = e.info.advertisement);
        });
        s = {
            trd_session: wx.getStorageSync("trd_session"),
            key: "pay_function"
        };
        tools.requset("?i=" + a.siteInfo.uniacid + "&c=entry&op=receive_card&do=config&m=" + a.modules_name + "&a=wxapp", s, function(e) {
            t.setData({
                pay_function: e.info ? e.info : 0
            });
        });
        s = {
            trd_session: wx.getStorageSync("trd_session"),
            key: "red_package_fee"
        };
        tools.requset("?i=" + a.siteInfo.uniacid + "&c=entry&op=receive_card&do=config&m=" + a.modules_name + "&a=wxapp", s, function(e) {
            t.data.red_package_fee = e.info ? e.info : 0;
        });
        s = {
            trd_session: wx.getStorageSync("trd_session")
        };
        tools.requset("?i=" + a.siteInfo.uniacid + "&c=entry&op=receive_card&do=release&m=" + a.modules_name + "&a=wxapp", s, function(e) {
            t.data.is_release = e.info.is_release, 0 == t.data.is_release && wx.showModal({
                title: "提示",
                mask: !0,
                content: e.info.msg,
                showCancel: !1,
                success: function(e) {
                    e.confirm;
                }
            });
        });
        s = {
            trd_session: wx.getStorageSync("trd_session")
        };
        tools.requset("?i=" + a.siteInfo.uniacid + "&c=entry&op=receive_card&do=voucher&m=" + a.modules_name + "&a=wxapp", s, function(e) {
            t.setData({
                is_voucher: e.status,
                voucher: e.info
            }), 1 == e.status && (t.data.setArray[0].cardname = "选择优惠券"), t.data.is_voucher = e.status, 
            t.data.voucher = e.info;
        }), getApp().tabhead(t);
        var i = new Date().getFullYear(), o = dateTimePicker.dateTimePicker(i, this.data.endYear);
        o.dateTimeArray.pop(), o.dateTime.pop();
        this.setData({
            dateTimeArray1: o.dateTimeArray,
            dateTime1: o.dateTime
        }), a.globalData.userInfo ? t.setData({
            userInfo: a.globalData.userInfo
        }) : t.setData({
            getUserLyaer: !0
        });
        var r = this.data.cropperOpt;
        new _weCropperMin2.default(r).on("ready", function(e) {
            console.log("wecropper is ready for work!");
        }).on("beforeImageLoad", function(e) {
            console.log("before picture loaded, i can do something"), console.log("current canvas context:", e), 
            wx.showToast({
                title: "加载中...",
                icon: "loading",
                duration: 2e4
            });
        }).on("imageLoad", function(e) {
            console.log("picture loaded"), console.log("current canvas context:", e), wx.hideToast();
        });
    },
    recommend: function(e) {
        var t = this;
        t.data.recommend ? t.setData({
            recommend: !1
        }) : t.setData({
            recommend: !0
        });
    },
    onReady: function() {
        var e = getApp(), t = this, a = {
            trd_session: wx.getStorageSync("trd_session"),
            key: "red_bag,voucher_open,default_prize_img,close_cmd_prize,cmd_prize_label"
        };
        tools.requset("?i=" + e.siteInfo.uniacid + "&c=entry&op=receive_card&do=configarr&m=" + e.modules_name + "&a=wxapp", a, function(e) {
            t.setData({
                red_bag: e.info.red_bag,
                voucher_open: e.info.voucher_open,
                bgimg: e.info.default_prize_img,
                close_cmd_prize: e.info.close_cmd_prize,
                cmd_prize_label: e.info.cmd_prize_label
            });
        });
    },
    advjump: function(e) {
        var t = this;
        wx.navigateToMiniProgram({
            appId: t.data.adv.appId,
            path: t.data.adv.xcx_path,
            extraData: t.data.adv.extradata,
            success: function(e) {
                console.log("success");
            },
            fail: function(e) {
                wx.showModal({
                    title: "",
                    content: e.errMsg,
                    showCancel: !1
                });
            }
        });
    },
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {},
    getUserInfo: function(e) {
        tools.userInfo(this, e);
    },
    addPrize: function(e) {
        var t = this.data.setArray;
        if (3 <= t.length) tools.showNotice("最多设置三项"); else {
            var a = {
                prIndex: 0,
                num: 1,
                money: "",
                prize: "",
                cardname: 1 == this.data.is_voucher ? "选择优惠券" : "",
                cardmsg: ""
            };
            t.push(a), this.setData({
                setArray: t
            });
        }
    },
    delset: function(e) {
        var t = this.data.setArray, a = e.currentTarget.dataset.index;
        t.splice(a, 1), this.setData({
            setArray: t
        });
    },
    bindPickerChange: function(e) {
        var t = this.data.setArray, a = e.target.dataset.index;
        t[a].prIndex = e.currentTarget.dataset.id, 2 == e.currentTarget.dataset.id && (t[a].num = 1, 
        max_group_num = 0), this.setData({
            setArray: t,
            max_group_num: max_group_num
        }), 1 == e.currentTarget.dataset.id && 1 == this.data.red_bag && 0 < this.data.red_package_fee && (this.data.red_bag = 2, 
        wx.showModal({
            title: "提示",
            mask: !0,
            content: "红包需要手续费" + this.data.red_package_fee + "%",
            showCancel: !1,
            success: function(e) {
                e.confirm;
            }
        }));
    },
    prizeInput: function(e) {
        var t = this.data.setArray;
        t[e.target.dataset.index].prize = e.detail.value, this.setData({
            setArray: t
        });
    },
    moneyInput: function(e) {
        var t = this.data.setArray;
        t[e.target.dataset.index].money = e.detail.value, this.setData({
            setArray: t
        });
    },
    cardnameInput: function(e) {
        var t = this.data.setArray;
        t[e.target.dataset.index].cardname = e.detail.value, this.setData({
            setArray: t
        });
    },
    cardnumInput: function (e) {
      var t = this.data.setArray, a = e.target.dataset.index, s = e.target.dataset.indextwo;
      t[a].cardmsg = e.detail.value, this.setData({
        setArray: t
      });
    },
    
    setinput: function(e) {
        var t = this.data.setArray, a = e.target.dataset.index, s = parseInt(e.detail.value);
        t[a].num = s, this.setData({
            setArray: t
        }), max_group_num = 0 <= s && s < 3 ? 0 : 3 <= s && s < 6 ? 3 : 6 <= s && s < 9 ? 6 : 9, 
        this.setData({
            max_group_num: max_group_num
        });
    },
    setPlus: function(e) {
        var t = this.data.setArray, a = e.target.dataset.index, s = parseInt(t[a].num), n = s += 1;
        console.log(a), console.log(e.target.dataset), t[a].num = n, this.setData({
            setArray: t
        }), max_group_num = 0 <= n && n < 3 ? 0 : 3 <= n && n < 6 ? 3 : 6 <= n && n < 9 ? 6 : 9, 
        this.setData({
            max_group_num: max_group_num
        });
    },
    setReduce: function(e) {
        var t = this.data.setArray, a = e.target.dataset.index, s = parseInt(t[a].num), n = s -= 1;
        0 < (t[a].num = n) && this.setData({
            setArray: t
        }), max_group_num = 0 <= n && n < 3 ? 0 : 3 <= n && n < 6 ? 3 : 6 <= n && n < 9 ? 6 : 9, 
        this.setData({
            max_group_num: max_group_num
        });
    },
    awardinput: function(e) {
        var t = parseInt(e.detail.value);
        this.setData({
            awardsNum: t
        });
    },
    numreduce: function(e) {
        var t = this.data.awardsNum;
        1 < t && (t -= 1, this.setData({
            awardsNum: t
        }));
    },
    numplus: function(e) {
        var t = this.data.awardsNum;
        t += 1, this.setData({
            awardsNum: t
        });
    },
    switch1Change: function(e) {
        this.setData({
            isshow: e.detail.value
        });
    },
    isShare: function(e) {
        console.log(e.detail.value), this.setData({
            is_command: e.detail.value ? 1 : 0,
            isshowcommand: e.detail.value
        });
    },
    addCover: function(e) {
        var a = this, t = e.detail.formId, s = wx.getStorageSync("trd_session"), n = {};
        n.trd_session = s, n.formid = t;
        getApp();
        console.log("test"), wx.chooseImage({
            count: 1,
            sizeType: [ "original", "compressed" ],
            sourceType: [ "album", "camera" ],
            success: function(e) {
                var t = e.tempFilePaths;
                a.wecropper.pushOrign(t[0]), a.setData({
                    crop: !0
                });
            }
        });
    },
    touchStart: function(e) {
        this.wecropper.touchStart(e);
    },
    touchMove: function(e) {
        this.wecropper.touchMove(e);
    },
    touchEnd: function(e) {
        this.wecropper.touchEnd(e);
    },
    cropimg: function(e) {
        var n = this, s = e.detail.formId;
        this.wecropper.getCropperImage(function(e) {
            if (e) {
                var t = {};
                t.formid = s;
                var a = wx.getStorageSync("trd_session");
                t.trd_session = a, tools.upload(e, t, function(e) {
                    var t = JSON.parse(e.data);
                    console.log(t);
                    var a = t.info, s = tools.imageurl(a);
                    console.log(s), n.setData({
                        bgimg: s,
                        crop: !1,
                        attach_id: a
                    });
                });
            } else console.log("获取图片地址失败，请稍后重试");
        });
    },
    conditionChange: function(e) {
        this.setData({
            conIndex: e.detail.value
        });
    },
    changeDateTime1: function(e) {
        var t = this.data.dateTimeArray1, a = e.detail.value, s = t[0][a[0]] + "-" + t[1][a[1]] + "-" + t[2][a[2]] + " " + t[3][a[3]] + ":" + t[4][a[4]];
        this.setData({
            dateTime1: e.detail.value,
            startTime: s
        });
    },
    changeDateTimeColumn1: function(e) {
        var t = this.data.dateTime1, a = this.data.dateTimeArray1;
        t[e.detail.column] = e.detail.value, a[2] = dateTimePicker.getMonthDay(a[0][t[0]], a[1][t[1]]), 
        this.setData({
            dateTimeArray1: a,
            dateTime1: t
        });
    },
    businessInput: function(e) {
        this.setData({
            business: e.detail.value
        });
    },
    command: function(e) {
        this.setData({
            command: e.detail.value
        });
    },
    appidInput: function(e) {
        this.data.appid = e.detail.value, console.log(e.detail.value);
    },
    appnameInput: function(e) {
        this.data.appname = e.detail.value, console.log(e.detail.value);
    },
    srcInput: function(e) {
        this.data.xcxpath = e.detail.value, console.log(e.detail.value);
    },
    paramsInput: function(e) {
        this.data.params = e.detail.value, console.log(e.detail.value);
    },
    jdexplain: function(e) {
        this.setData({
            jdexplain: e.detail.value,
            jdnum: e.detail.value.length
        });
    },
    cjexplain: function(e) {
        this.setData({
            remarks: e.detail.value,
            cjnum: e.detail.value.length
        });
    },
    payswitch: function(e) {
        var t = e.currentTarget.dataset.id;
        this.data.copyorjump = t, this.setData({
            copyorjump: t
        });
    },
    copyInput: function(e) {
        console.log(e.currentTarget.dataset.field), "copyname" == e.currentTarget.dataset.field ? this.setData({
            copyname: e.detail.value
        }) : this.setData({
            wechat_title: e.detail.value
        });
    },
    group: function(e) {
        this.data.group ? this.setData({
            group: !1
        }) : this.setData({
            group: !0
        });
    },
    groupno: function(e) {
        this.setData({
            group: !1
        });
    },
    againcard: function(e) {
        var t = this.data.setArray, a = e.currentTarget.dataset.index;
        t[a].cardmsg.push(""), 3 <= t[a].cardmsg.length && (max_group_num = 3), this.setData({
            setArray: t,
            max_group_num: max_group_num
        });
    },
    isgroup: function(e) {
        this.data.max_group_num < 3 ? tools.showNotice("奖品数量不足") : this.data.isgroup ? this.setData({
            isgroup: !1
        }) : this.setData({
            isgroup: !0
        });
    },
    explainChange: function(e) {
        this.setData({
            expIndex: e.detail.value
        });
    },
    addImg: function() {
        var n = this;
        n.data.imgs && 7 <= n.data.imgs.length ? tools.showNotice("最多上传7张") : wx.chooseImage({
            count: 1,
            success: function(e) {
                var t = [];
                n.data.imgs && (t = n.data.imgs), e.tempFiles.forEach(function(e) {
                    t.push(e.path);
                }), n.setData({
                    imgs: t
                });
                var a = {}, s = wx.getStorageSync("trd_session");
                a.trd_session = s, tools.upload(e.tempFiles[0].path, a, function(e) {
                    var t = JSON.parse(e.data).info, a = n.data.remarksImg + t + ",";
                    n.setData({
                        remarksImg: a
                    });
                });
            }
        });
    },
    addImg2: function () {
      var n = this;
      n.data.img && 1 <= n.data.img.length ? tools.showNotice("最多上传1张") : wx.chooseImage({
        count: 1,
        success: function (e) {
          var t = [];
          n.data.img && (t = n.data.img), e.tempFiles.forEach(function (e) {
            t.push(e.path);
          }), n.setData({
            img: t,
            hasImg:!1
          });
          var a = {}, s = wx.getStorageSync("trd_session");
          a.trd_session = s, tools.upload(e.tempFiles[0].path, a, function (e) {
            var t = JSON.parse(e.data).info;
            n.setData({
              wechatImg: t
            });
          });
        }
      });
    },
    choicecourp: function(e) {
        var t = e.currentTarget.dataset.index;
        this.setData({
            courplayer: !0,
            choiceindex: t
        });
    },
    choice: function(e) {
        var t = this.data.setArray;
        t[this.data.choiceindex].cardname = e.currentTarget.dataset.name, t[this.data.choiceindex].cardid = e.currentTarget.dataset.id, 
        this.setData({
            courplayer: !1,
            setArray: t
        });
    },

  submit: function (a) {
    if (0 != this.data.is_release) {
      var s = this, c = getApp();
      //获取各内容
      var r = '', q = '',p = '',v = '';
      r = s.data.remarksImg;
      r = "," == r.substring(r.length - 1) ? r.substring(0, r.length - 1) : r;
      s.data.isshowcondition == !1 ? q = 0 : q = s.data.condition;
      0 == s.data.conIndex ? p = 'people' : 1 == s.data.conIndex ? p = 'time' : p = 'manual';
      if (p == "time"){
        if ("请选择时间" == s.data.startTime){
          tools.showNotice("请选择时间");
        }else{
          v = s.data.startTime;
        }
      }
      if (p == "people"){
        if (s.data.awardsNum <= 0){
          tools.showNotice("请填写开奖人数");
        }else{
          v = s.data.awardsNum
        }
      }
      var e = {
        trd_session: wx.getStorageSync("trd_session"),
        versions: '2',                  //版本
        formid: a.detail.formId,        //点击获取formID
        attach_id: s.data.attach_id,    //奖品图片id
        is_command: s.data.is_command,  //是否口令
        command: s.data.command,        //口令
        title: s.data.jdexplain,        //标题
        contact: s.data.telnumber,      //联系方式
        desc_type: 0,                   //详细说明类型
        descriptionImg: r,              //详细说明图片
        descriptionText: s.data.remarks,//详细说明文字
        condition: q,                   //抽奖条件
        uname: s.data.business,         //赞助商
        isjump: 1,                      //是否有跳转
        copyorjump: s.data.copyorjump,  //跳转类型
        wechat_no: s.data.copyname,     //复制的微信号
        wechat_title: s.data.wechat_title, //微信号描述
        wechatImg: s.data.wechatImg,    //跳转的小程序图片
        appname: s.data.appname,        //小程序名称
        type: p,                        //开奖类型
        typevalue: v,                   //开奖人数|| 开奖时间
        is_share: s.data.is_share,      //是否分享
        pay: s.data.pay
      };
      //判断奖品类型，并获取值
      var d = '';
      d = s.data.setArray;
      if (1 == s.data.is_command && "" == s.data.command) { tools.showNotice("请输入抽奖口令") };

      // 第一个
      if (0 == d[0].prIndex && "" == d[0].prize) return void tools.showNotice("请输入奖品名称");
      if (2 == d[0].prIndex && "" == d[0].cardname) return void tools.showNotice("请输入卡名称");
      if (d[0]) {
        if (0 == d[0].prIndex) {
          e.fir_val = d[0].prize;
          e.fir_num = d[0].num;
        } else {
          e.fir_cname = d[0].cardname;
          e.fir_cardmsg = d[0].cardmsg;
        }
        e.fir_ptype = d[0].prIndex;
      } else e.fir_num = s.data.fir_num, e.fir_ptype = s.data.fir_ptype, e.fir_val = s.data.fir_val;
      // 第二个
      if (d[1]) {
        if (0 == d[1].prIndex && "" == d[1].prize) return void tools.showNotice("请输入奖品名称");
        if (2 == d[1].prIndex && "" == d[1].cardname) return void tools.showNotice("请输入卡名称");
        if (0 == d[1].prIndex) {
          e.sec_val = d[1].prize;
          e.sec_num = d[1].num;
        } else {
          e.sec_cname = d[1].cardname;
          e.sec_cardmsg = d[1].cardmsg;
        }
        e.sec_ptype = d[1].prIndex;
      } else e.sec_num = s.data.sec_num, e.sec_ptype = s.data.sec_ptype, e.sec_val = s.data.sec_val;
      // 第三个
      if (d[2]) {
        if (0 == d[2].prIndex && "" == d[2].prize) return void tools.showNotice("请输入奖品名称");
        if (2 == d[2].prIndex && "" == d[2].cardname) return void tools.showNotice("请输入卡名称");
        if (0 == d[2].prIndex) {
          e.trd_val = d[2].prize;
          e.trd_num = d[2].num;
        } else {
          e.trd_cname = d[2].cardname;
          e.trd_cardmsg = d[2].cardmsg;
        }
        e.trd_ptype = d[2].prIndex;
      } else e.trd_num = s.data.trd_num, e.trd_ptype = s.data.trd_ptype, e.trd_val = s.data.trd_val;
      console.log(e.trd_cardmsg);

      tools.requset("?i=" + c.siteInfo.uniacid + "&c=entry&op=receive_card&do=add&m=" + c.modules_name + "&a=wxapp", e, function (e) {
        if (-1 == e.status) s.setData({
          getUserLyaer: !0
        });
        else if (-2 == e.status) wx.showModal({
          title: "提示",
          mask: !0,
          content: e.info.msg,
          showCancel: !1,
          success: function (e) {
            return !1;
          }
        });
        else if (2 == e.status)
          wx.requestPayment({
            timeStamp: e.info.timeStamp,
            nonceStr: e.info.nonceStr,
            package: e.info.package,
            signType: e.info.signType,
            paySign: e.info.paySign,
            success: function (e) {
              setTimeout(function () {
                s.setData({ pay: 'check' });
                s.submit(a);
              }, 1500);
            },
            fail: function (e) {
              console.log(e);
            }
          });
        else if (0 == e.status) tools.showNotice(e.info);
        else {
          var t = e.info;
          wx.navigateTo({
            url: "../partake/partake?id=" + t
          });
        }
        return !0;
      });

    } else wx.showModal({ //无权限发布
      title: "提示",
      mask: !0,
      content: "无发布权限",
      showCancel: !1,
      success: function (e) {
        e.confirm;
      }
    });
  },
  help: function (t) {
    wx.redirectTo({
      url: "../help/help"
    });
  },
  iscondition: function(e){
      console.log(e.detail.value), this.setData({
      iscondition: e.detail.value ? 1 : 0,
      isshowcondition: e.detail.value
    });
  },
  conditionID1: function(){
      this.setData({
        condition:1
      })
  },
  conditionID2: function () {
    this.setData({
      condition: 2
    })
  },
  pagegoback: function () {
    wx.navigateBack({
      delta: 1
    });
  },
});
function _defineProperty(t, n, e) {
    return n in t ? Object.defineProperty(t, n, {
        value: e,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : t[n] = e, t;
}

var tools = require("../../utils/tools.js");

function actDetail(t, n) {
    t.setData({
        url: n.purl
    });
}

Page({
    data: {},
    onLoad: function(t) {
        var n = this;
        getApp().tabhead(n), t.id && n.setData({
            id: t.id
        }), actDetail(n, t);
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {},
    copy: function(t) {
        var n = t.currentTarget.dataset.name;
        wx.setClipboardData({
            data: n,
            success: function(t) {
                wx.showToast({
                    title: "复制成功！"
                });
            }
        });
    }
});
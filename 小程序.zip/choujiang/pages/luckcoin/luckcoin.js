var tools = require("../../utils/tools.js"), QR = require("../../utils/qrcode.js"), WxParse = require("../../wxParse/wxParse.js"), touchDot = 0, touchend = 0;

Page({
  data: {
    num:0,
    goodsList:''
  },
  onLoad: function (e) {
    var t = this, a = getApp(), s = {
      trd_session: wx.getStorageSync("trd_session")
    };
    tools.requset("?i=" + a.siteInfo.uniacid + "&c=entry&op=receive_card&do=luck&m=" + a.modules_name + "&a=wxapp", s, function (e) {
      t.setData({
        num: e.info.integral ? e.info.integral : 0,
        goodsList: e.info.goodsList
      });
    }), getApp().tabhead(t);

  },
  toRule: function (t) {
    wx.navigateTo({
      url: "../luckhelp/luckhelp"
    });
  },
  dayTask: function (t) {
    wx.navigateTo({
      url: "../luckwechat/luckwechat"
    });
  },
  exchange: function (t) {
    var a = t.currentTarget.dataset.id;
    a ? wx.navigateTo({
      url: "../luckgood/luckgood?gid=" + a
    }) : wx.showToast({
      title: "即将开放，敬请期待",
      icon: "none",
      duration: 1e3
    });
  },
});
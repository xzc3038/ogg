var that, tools = require("../../utils/tools.js");

Page({
  data: {
    
  },
  onLoad: function (t) {
    that = this;
    var a = getApp(), s = {
      trd_session: wx.getStorageSync("trd_session")
    };
    tools.requset("?i=" + a.siteInfo.uniacid + "&c=entry&op=receive_card&do=help&m=" + a.modules_name + "&a=wxapp", s, function (e) {
      console.log(e.info);
      that.setData({
        data: e.info
      });
    }), that.setData({
      headtxt: "发布抽奖"
    }), getApp().tabhead(that);
  },
  addWx: function (t) {
    if (this.data.data.type == 0) {
      this.setData({
        wxcopy: !0
      });
    } else {
      this.setData({
        wxpop: !0
      });
    }

  },
  addView: function (t) { },
  saveImg: function (o) {
    var e = this;
    e.setData({
      wxpop: !1
    }), wx.getSetting({
      success: function (t) {
        console.log(t.authSetting), t.authSetting["scope.writePhotosAlbum"] ? e.saveImage() : 0 == t.authSetting["scope.writePhotosAlbum"] ? e.setData({
          wxpop: !1,
          isSave: !0
        }) : e.saveImage();
      },
      fail: function (t) {
        wx.showToast({
          title: "保存失败",
          icon: "none",
          duration: 2e3
        });
      }
    });
  },
  saveImage: function (t) {
    var s = this;
    wx.getImageInfo({
      src: s.data.data.img,
      success: function (t) {
        wx.saveImageToPhotosAlbum({
          filePath: t.path,
          success: function (t) {
            wx.showToast({
              title: "保存成功",
              icon: "success",
              duration: 2e3
            });
          }
        });
      },
      fail: function (t) {
        console.log(t), wx.showToast({
          title: "保存失败",
          icon: "none",
          duration: 2e3
        });
      }
    });
  },
  popSet: function (t) {
    this.setData({
      isSave: !1
    });
  },
  popCancel1: function (t) {
    this.setData({
      wxpop: !1,
      isSave: !1,
      wxcopy: !1,
    });
  },
  copyWx: function (o) {
    wx.setClipboardData({
      data: "zm888779",
      success: function (t) {
        wx.getClipboardData({
          success: function (t) { }
        });
      }
    });
  },
  copy: function () {
    var t = this;
    wx.setClipboardData({
      data: t.data.data.text,
      success(res) {
        wx.getClipboardData({
          success(res) {
            wx.showToast({
              title: '复制成功',
              icon: 'success'
            })
          }
        })
      }
    })
  }
});
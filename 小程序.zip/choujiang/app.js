var util = require("utils/common.js");
var a = require("utils/api.js");
App({
    editTabBar: function(e) {
        var t = this.globalData.tabbar, s = getCurrentPages(), n = s[s.length - 1], o = n.__route__;
        for (var a in 0 != o.indexOf("/") && (o = "/" + o), t.list) t.list[a].selected = !1, 
        t.list[a].pagePath == o && (t.list[a].selected = !0);
        n.setData({
            tabbar: t
        });
    },
    tabhead: function(t) {
        wx.getSystemInfo({
            success: function(e) {
                -1 < e.model.indexOf("iPhone X") ? t.setData({
                    headheight: 88
                }) : t.setData({
                    headheight: 70
                });
            }
        });
    },
    onLaunch: function(e) {
        if (e) {
            var t = e.scene;
            e.path;
            1007 !== t && 1008 != t || console.log("私聊群聊打开小程序");
        }
        var s = wx.getStorageSync("trd_session") || "";
        "" === s ? wx.login({
            success: this.loginCallback
        }) : wx.checkSession({
            success: function() {},
            fail: function() {
                wx.login({
                    success: this.loginCallback
                });
            }
        }), this.globalData.userInfo = wx.getStorageSync("userInfo" + s);
    },
    globalData: {
        userInfo: null,
        currTabFlag: null,
        scene: "",
        tabbar: {
            color: "#9F9494",
            selectedColor: "#F07575",
            backgroundColor: "#ffffff",
            borderStyle: "black",
            list: [ {
                pagePath: "/pages/news/news",
                text: "抽奖",
                iconPath: "../../images/icon_index_1.png",
                selectedIconPath: "../../images/icon_index.png",
                selected: !0
            }, {
                pagePath: "/pages/first/first",
                text: "发起抽奖",
                iconPath: "../../images/icon_lottery.png",
                selectedIconPath: "../../images/icon_lottery2.png",
                selected: !1
            }, {
                pagePath: "/pages/my1/my",
                text: "我的",
                iconPath: "../../images/icon_mine_1.png",
                selectedIconPath: "../../images/icon_mine.png",
                selected: !1
            } ]
        }
    },
    sendFormid: function (e) {
      a.sendFormid({
        num: 2,
        data: {
          formid: e
        },
        success: function (a) { }
      });
    },
    relogin: function(t, s, n, o) {
        var a = require("utils/tools.js"), i = this;
        wx.login({
            success: function(e) {
                void 0 === s && (s = {});
                i.loginCallback(e, function(e) {
                    s.trd_session = e, a.requset(t, s, n, o);
                });
            }
        });
    },
    loginCallback: function(e, t) {
        var s = wx.getStorageSync("trd_session") || "";
        if (wx.removeStorageSync("trd_session"), wx.removeStorageSync("userInfo" + s), e.code) {
            var n = require("utils/tools.js"), o = getApp();
            n.requset("?i=" + o.siteInfo.uniacid + "&c=entry&op=receive_card&do=login&m=" + o.modules_name + "&a=wxapp", {
                code: e.code
            }, function(e) {
                if (1 != e.status) return console.log(e), wx.showModal({
                    title: "提示",
                    mask: !0,
                    content: e.info,
                    showCancel: !1,
                    success: function(e) {
                        e.confirm;
                    },
                    fail: function(e) {
                        console.log(e);
                    }
                }), !1;
                wx.setStorageSync("trd_session", e.info), "function" == typeof t && t(e.info);
            });
        } else console.log("获取用户登录态失败！" + e.errMsg);
    },
    modules_name: "hu_couda",
    util: require("we7/resource/js/util.js"),
    siteInfo: require("siteinfo.js")
});